"""Record final sources and observed verification results, without device access."""
import hashlib,json,re,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[1];folder=root/'docs/experiment-logs'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
condition=json.loads((folder/'2026-11-20-motion-v168-condition.json').read_text())
for name,digest in condition['sha256'].items():
    if name.startswith(('src/','include/','.pio/observer-build/')):assert sha(root/name)==digest
summary=json.loads((folder/'2026-11-20-motion-resumed-summary.json').read_text())
for r in summary['records']:assert sha(root/Path(r['log'].replace('\\','/')))==r['sha256']
files=[root/name for name in ('src/main.cpp','platformio.ini','.gitattributes','AGENTS.md','README.md','docs/experiment-status.md','docs/bench-motion-plan.md')]
files+=sorted((root/'include').glob('*.h'))+sorted((root/'tools').glob('*.py'))
files += [p for p in (root/'test').rglob('*') if p.is_file() and p.suffix in ('.py','.h','.cpp') and '__pycache__' not in p.parts]
files += [root/'.pio/observer-build/disco_b_g431b_esc1'/name for name in ('firmware.elf','firmware.bin')]
files += [root/'.pio'/name for name in ('finalize-motion-20261120.py','plot_motion_matrix_20261120.py','update-motion-summary-20261120.py','archive-motion-final-checkpoint-20261120.py')]
files=sorted(set(files));archive=folder/'2026-11-20-motion-final-checkpoint.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.relative_to(root).as_posix())
fingerprint=hashlib.sha256(b''.join(p.read_bytes() for p in sorted((root/'tools').glob('*.py')))).hexdigest()
data={'scope':'Final reviewable repository state after all physical experiments; later PC-side failed-candidate refusal has not been used for additional driving.',
    'firmware_version':168,'firmware_rpm':40,'firmware_shape':1,'build_flags':condition['build_flags'],
    'final_physical_state':'outputs OFF, gate inputs LOW, all drives locked until reset; no device-operation processes',
    'archive_sha256':sha(archive),'files_sha256':{p.relative_to(root).as_posix():sha(p) for p in files},'final_host_source_fingerprint':fingerprint,
    'observed_passed_checks':['8 native trajectory variants with current cap .45 (2026-11-20-motion-native-all-trajectories.txt)',
       'test/motion_failed_candidates.py: both failed 10rpm baselines/directions refused before serial enumeration, file creation and reset',
       'test/motion_capture_protocol.py: 11 virtual serial cases and stale-profile refusal; no real serial/reset/upload',
       'test/motion_repetition_seeds.py: explicit seed identity/profile/normal-completion checks',
       'test/motion_summary.py: both dated archives, all seven new conditions and corruption rejection without .pio',
       'test/motion_stop_log.py: actual fast-stop audit and rejection of stop/ACK/motion/gate tampering',
       'All 17 historical summary records/all fields unchanged; 57 CSV records with consistent columns',
       'All 57 raw evidence hashes preserved; current C++/ELF/bin match v168 condition; git diff --check passed']}
with (folder/'2026-11-20-motion-final-checkpoint.json').open('x',encoding='utf-8') as f:json.dump(data,f,indent=2)
print(f'Archived {len(files)} final source/test/build files; all 57 raw logs unchanged; no device access')
