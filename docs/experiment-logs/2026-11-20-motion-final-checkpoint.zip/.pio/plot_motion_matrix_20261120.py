import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parents[1];folder=root/'docs/experiment-logs'
records=[r for r in json.loads((folder/'2026-11-20-motion-resumed-summary.json').read_text())['records'] if r['kind']=='motion' and 161<=r['firmware_version']<=168]
fig,axes=plt.subplots(2,2,figsize=(11,7),constrained_layout=True)
for shape in (0,1):
    rows=[r for r in records if r['motion']['shape']==shape]
    for col,key,limit,label in ((0,'max_error_joint_deg',.5,'Peak position error (joint deg)'),(1,'rms_iq_error_nominal_A',.05,'Iq error RMS (nominal A)')):
        ax=axes[shape,col];used=set()
        for i,r in enumerate(rows):
            direction=int(r['motion']['direction']);normal=r['stop']=='STOP: bench motion sequence complete'
            description=('positive start' if direction==1 else 'negative start') if normal else 'protective stop (partial)'
            moving=[m for m in r['moving'] if m['FOC_samples']]
            x=r['motion']['rpm']+direction*.7+((i%3)-1)*.22
            ax.scatter(x,max(m[key] for m in moving),marker=('^' if direction==1 else 'v') if normal else 'x',color=('#2471a3' if direction==1 else '#d35400') if normal else '#b00020',s=42,label=description if description not in used else None)
            used.add(description)
        ax.axhline(limit,color='#b00020',linestyle='--',linewidth=1,label='criterion')
        ax.set_xticks((10,20,40,60));ax.set_xlim(5,65);ax.set_ylim(bottom=0);ax.set_xlabel('Reference peak motor rpm');ax.set_ylabel(label)
        ax.set_title('Quintic' if shape==0 else 'Trapezoidal speed: 100ms accel / 25ms decel');ax.grid(True,alpha=.25);ax.legend(fontsize=8)
fig.suptitle('Bare motor, identical controller / Iq cap 0.45 nominal A, 30 degree return motions\n40 trials: 38 normal completions, 2 protective stops, 8 canceled; no overall performance passes',fontsize=11)
fig.supxlabel('Fault points retain partial intervals; canceled trials are absent. Same-ABI motor / 8; no loaded or absolute-angle validation.',fontsize=9)
out=folder/'2026-11-20-motion-range045-matrix.png';assert not out.exists();fig.savefig(out,dpi=170)
print(out)
