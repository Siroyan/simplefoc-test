"""Evidence summary of all motion attempts; no device access or success filtering."""
import argparse,csv,hashlib,json,re
from pathlib import Path
from analyze_motion import analyze_motion

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--csv',required=True);args=p.parse_args()
    root=Path(__file__).resolve().parents[1];records=[]
    for path in sorted((root/'docs/experiment-logs').glob('2026-11-19-motion-*.log')):
        text=path.read_text(encoding='utf-8')
        if 'HOST sending one command=' not in text:continue
        if 'HOST final_stop_acknowledged=True' not in text.splitlines():raise ValueError(f'Unfinished motion capture: {path.name}')
        result=analyze_motion(path)
        result['log']=str(path.relative_to(root));result['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
        result['firmware_version']=int(re.search(r'FIRMWARE diag_version=(\d+)',text)[1])
        result['profile_text']=next(s for s in text.splitlines() if s.startswith('BENCH_MOTION '))
        condition=root/f"docs/experiment-logs/2026-11-19-motion-v{result['firmware_version']}-condition.json"
        condition_data=json.loads(condition.read_text(encoding='utf-8'));snapshot=root/condition_data['snapshot_directory']
        for name,digest in condition_data['sha256'].items():
            if hashlib.sha256((snapshot/Path(name).name).read_bytes()).hexdigest()!=digest:raise ValueError('Archived condition source/ELF/header hash mismatch')
        result['condition']=str(condition.relative_to(root));result['final_stop_acknowledged']=True
        records.append(result)
    groups={}
    for result in records:
        signature=re.sub(r'direction=-?1 ', 'direction=both ',result['profile_text'])+'|'+json.dumps(result['active_config'],sort_keys=True)+'|'+result['estimator']
        group=groups.setdefault(signature,{'normal_complete':{'1':0,'-1':0},'performance_pass':{'1':0,'-1':0},'protective_stop':{'1':0,'-1':0},'logs':[]})
        direction=str(int(result['motion']['direction']));normal=result['stop']=='STOP: bench motion sequence complete'
        group['normal_complete'][direction]+=int(normal);group['performance_pass'][direction]+=int(result['pass'])
        group['protective_stop'][direction]+=int(not normal and result['stop']!='STOP: serial stop');group['logs'].append(result['log'])
    data={'scope':'All saved standalone motor motion attempts, including failures; no goal-completion inference.',
          'supply_V':11.1,'input_current_limit_A':.8,'records':records,'groups':groups}
    with Path(args.output).open('x',encoding='utf-8') as f:json.dump(data,f,indent=2)
    columns=['firmware','rpm','shape','direction','stop','whole_trace','performance_pass','max_moving_error_joint_deg','max_moving_rms_joint_deg','max_moving_iq_rms_nominal_A','max_hold_error_joint_deg','max_peak_motor_rpm','log']
    with Path(args.csv).open('x',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=columns);w.writeheader()
        for r in records:
            moving=[v for v in r['moving'] if v['FOC_samples']];holds=[v for v in r['holds'] if v['tail_samples']]
            w.writerow(dict(firmware=r['firmware_version'],rpm=r['motion']['rpm'],shape=r['motion']['shape'],direction=r['motion']['direction'],stop=r['stop'],whole_trace=r['whole_trace'],performance_pass=r['pass'],
                max_moving_error_joint_deg=max((v['max_error_joint_deg'] for v in moving),default=None),max_moving_rms_joint_deg=max((v['rms_error_joint_deg'] for v in moving),default=None),
                max_moving_iq_rms_nominal_A=max((v['rms_iq_error_nominal_A'] for v in moving),default=None),max_hold_error_joint_deg=max((v['tail_max_error_joint_deg'] for v in holds),default=None),
                max_peak_motor_rpm=max((v['peak_motor_rpm'] for v in moving),default=None),log=r['log']))
    print(json.dumps({'records':len(records),'normal_complete':sum(v['stop']=='STOP: bench motion sequence complete' for v in records),'performance_pass':sum(v['pass'] for v in records),'all_final_stop_acknowledged':True}))

if __name__=='__main__':main()
