@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cl /nologo /O2 /EHsc /std:c++17 /W4 /Iinclude test\fast_current_model.cpp /Fo.pio\ /Fe.pio\fast-current-model.exe >.pio\fast-current-model-build.log 2>&1
if errorlevel 1 exit /b 1
.pio\fast-current-model.exe
