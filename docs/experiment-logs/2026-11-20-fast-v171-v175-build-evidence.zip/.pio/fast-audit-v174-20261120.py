"""All six actual fast trials, retained failures, and next unflashed candidate."""
import difflib,hashlib,json,re,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[1];folder=root/'docs/experiment-logs'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
for version,rpm in ((169,120),(170,240),(171,240),(172,240),(173,240),(174,360)):
    log=folder/f'2026-11-20-fast-{rpm}-positive-v{version}-01.log';result=json.loads(log.with_suffix('.json').read_text())
    condition=json.loads((folder/f'2026-11-20-fast-v{version}-condition.json').read_text());archive=folder/f'2026-11-20-fast-v{version}-condition.zip'
    assert sha(archive)==condition['archive_sha256']
    with zipfile.ZipFile(archive) as z:
        for name,digest in condition['source_sha256'].items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
        host={name:z.read(name) for name in z.namelist() if name.startswith('tools/') and name.endswith('.py')}
        fingerprint=hashlib.sha256(b''.join(host[name] for name in sorted(host))).hexdigest()
    text=log.read_text();assert re.search(r'^HOST python_source_fingerprint=(\w+)',text,re.M)[1]==fingerprint==condition['host_source_fingerprint']
    assert 'HOST final_stop_acknowledged=True' in text
    idle=folder/f'2026-11-20-fast-v{version}-idle-01.log';off=idle.read_text()
    assert 'gate_inputs_low=1' in off and f'FIRMWARE diag_version={version}' in off and 'HOST verified: STOP acknowledged, drive locked until reset, five output-OFF rows' in off
    records.append({'version':version,'rpm':rpm,'log':log.name,'sha256':sha(log),'condition':f'2026-11-20-fast-v{version}-condition.json','idle_sha256':sha(idle),'result':result})
baseline=json.loads((folder/'2026-11-20-fast-v174-condition.json').read_text());proposal=json.loads((folder/'2026-11-20-fast-v175-proposal.json').read_text())
for name in ('include/BenchHighSpeedMotion.h','include/BenchCurrentGuard.h','include/BoardCurrentObserver.h','include/ObservationGuard.h','include/EdgeVelocity.h','include/BenchMotionStats.h'):
    assert baseline['source_sha256'][name]==proposal['source_sha256'][name]
for suffix in ('firmware.elf','firmware.bin'):
    name='.pio/fast-live-build/disco_b_g431b_esc1/'+suffix;assert sha(root/name)==baseline['source_sha256'][name]
assert proposal['state']=='built_not_flashed' and proposal['vector_limit_V']==1 and proposal['iq_limit_nominal_A']==.4 and proposal['q_current_LPF_s']==.0005
assert sha(folder/'2026-11-20-fast-v175-proposal.zip')==proposal['archive_sha256']
with zipfile.ZipFile(folder/'2026-11-20-fast-v174-condition.zip') as z:
    changes=[]
    for name in ('src/main.cpp','include/TrackingCurrentPI.h','include/MagnitudeSlew.h','tools/capture_motion.py','tools/bench_metadata.py','tools/fast_motion_profile.py','tools/analyze_bench.py','tools/analyze_fast_motion.py','tools/save_fast_condition.py','test/fast_voltage_upgrade.py'):
        before=z.read(name).decode('utf-8').replace('\r\n','\n').splitlines(keepends=True) if name in z.namelist() else []
        changes.extend(difflib.unified_diff(before,(root/name).read_text(encoding='utf-8').splitlines(keepends=True),fromfile='v174/'+name,tofile='v175/'+name))
patch=folder/'2026-11-20-fast-voltage10-v175.patch'
with patch.open('x',encoding='utf-8',newline='') as f:f.write(''.join(changes))
artifacts=folder/'2026-11-20-fast-v171-v175-build-evidence.zip'
files=[root/'.pio'/f'{kind}-v{v}.log' for v in (171,172,173,174) for kind in ('build','upload') if (root/'.pio'/f'{kind}-v{v}.log').exists()]
files += [root/'.pio/build-fast-proposal171.log',root/'.pio/build-fast-proposal175.log',Path(__file__).resolve(),root/'.pio/fast-current-model.cmd',root/'test/fast_current_model.cpp',root/'test/fast_voltage_upgrade.py',root/'test/tracking_voltage_limit.cpp']
with zipfile.ZipFile(artifacts,'x',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.relative_to(root).as_posix())
data={'scope':'Every actual fast trial v169-v174, including four protective stops and no identical fault retries. Not 3733rpm or jump qualification.',
      'records':records,'normal_complete':sum(r['result']['normal_complete'] for r in records),'protective_stops':sum(not r['result']['normal_complete'] for r in records),
      'physical_version':174,'physical_outputs_OFF_locked':True,'physical_elf_bin_preserved':True,
      'candidate_version':175,'candidate_state':'built_not_flashed','candidate_voltage_V':1.,'candidate_Iq_cap_A':.4,
      'waveform_current_ADC_guard_and_estimator_hashes_unchanged_from_v174':True,
      'proposal_sha256':proposal['archive_sha256'],'proposal_patch_sha256':sha(patch),'build_evidence_sha256':sha(artifacts)}
with (folder/'2026-11-20-fast-v174-summary-audit.json').open('x',encoding='utf-8') as f:json.dump(data,f,indent=2)
print('PASS: all six captures/source archives/runtime fingerprints/stop locks audited; physical v174 ELF/bin retained; unflashed v175 bounds verified')
