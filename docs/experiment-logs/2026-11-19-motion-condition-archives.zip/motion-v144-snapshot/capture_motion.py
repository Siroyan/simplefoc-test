"""One bounded bare-motor motion capture. No automatic reset, upload or retry."""
import argparse,re,time
from datetime import datetime
from pathlib import Path
import serial
from serial.tools import list_ports
from bench_metadata import verify_bench_current_loop
from motion_profile import PROFILE,verify_motion,fields

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--port',default='COM10');p.add_argument('--rpm',type=int,choices=(10,20,40,60),required=True)
    p.add_argument('--shape',type=int,choices=(0,1),default=0);p.add_argument('--direction',type=int,choices=(-1,1),required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--stop-after-ms',type=int)
    args=p.parse_args();command=b'"' if args.direction==1 else b'|'
    ports=[v for v in list_ports.comports() if v.device==args.port and v.vid==0x0483 and v.pid==0x374b]
    if len(ports)!=1:raise RuntimeError('Expected ST-LINK VCP missing; no reset/retry')
    with args.output.open('x',encoding='utf-8',buffering=1) as log:
        def record(s):
            log.write(s+'\n')
            if not re.match(r'^\d',s) and not s.startswith('MOTION_STATS '):print(s,flush=True)
        with serial.Serial(args.port,115200,timeout=.05,write_timeout=1) as link:
            buffer=b''
            def read():
                nonlocal buffer
                buffer+=link.read(max(1,link.in_waiting));out=[]
                while b'\n' in buffer:
                    row,buffer=buffer.split(b'\n',1);s=row.decode('ascii',errors='strict').strip('\r')
                    if s:record(s);out.append(s)
                return out
            def send(b):link.write(b);link.flush()
            record(f'HOST start={datetime.now().astimezone().isoformat()} port={args.port}')
            record('HOST supply=11.1V current_limit=0.8A; nominal phase/Iq limits are separate; CV and temperature unmeasured')
            sent=False
            try:
                # Confirm live output-OFF rows, then physical gate and PWM registers.
                end=time.monotonic()+3;off=0
                while time.monotonic()<end and off<3:
                    for s in read():
                        if re.match(r'^\d+,0,',s) and abs(float(s.split(',')[-1]))<1e-8:off+=1
                if off<3:raise RuntimeError('No live disabled telemetry; drive not started')
                send(b'c');end=time.monotonic()+2;pwm=False
                while time.monotonic()<end and not pwm:
                    for s in read():
                        if s.startswith('PWM '):
                            v=fields(s)
                            if any(v.get(k)!=x for k,x in {'hz':12500,'system_clock_Hz':170000000,'tim1_psc':0,'tim1_arr':6799,'gate_inputs_low':1,'rcc_cfgr':15}.items()) or int(v.get('tim1_bdtr',0))&255!=0x84 or int(v.get('tim1_cr1',0))&0x360!=0x40:raise RuntimeError('PWM/gate invariant mismatch')
                            pwm=True
                if not pwm:raise RuntimeError('Missing PWM confirmation')
                record(f'HOST sending one command={command.decode()} rpm={args.rpm} shape={args.shape} direction={args.direction}')
                send(command);sent=True
                verified=set();end=time.monotonic()+32;trace=False;stopped=False;off=0;stop_deadline=None;live_stop=False
                while time.monotonic()<end:
                    if stop_deadline is not None and not live_stop and time.monotonic()>=stop_deadline:
                        send(b's');live_stop=True;record('HOST live serial stop sent')
                    for s in read():
                        if s.startswith('BENCH_PROFILE '):
                            if s!=PROFILE:raise RuntimeError('Motion current/protection profile mismatch')
                            verified.add('profile')
                        if s.startswith('CURRENT_CONFIG '):
                            v=fields(s)
                            if any(v.get(k)!=x for k,x in {'observer_only':0,'deviation_delay_us':20000,'max_age_us':2000,'nominal_ADC_ref_V':3.3,'shunt_ohm':.003}.items()) or not 10<v.get('bus_low_V',0)<10.9 or not 11.5<v.get('bus_high_V',0)<12.5:raise RuntimeError('ADC/Vbus guard mismatch')
                            verified.add('observer')
                        if s.startswith('BENCH_MOTION '):verify_motion(s,args.rpm,args.shape,args.direction);verified.add('motion')
                        if s.startswith('ESTIMATOR '):
                            if s!='ESTIMATOR controller=rolling_LS4ms min_sample_us=150 warmup_span_us=3000 guard=original_window2ms_LPF2ms guard_limit=BENCH_MOTION':raise RuntimeError('Independent/controller velocity estimators mismatch')
                            verified.add('estimator')
                        if s.startswith('CURRENT_LOOP '):verify_bench_current_loop(s);verified.add('loop')
                        if s.startswith('CURRENT_TRACKING_ACTIVE '):
                            if s!='CURRENT_TRACKING_ACTIVE q_backcalc_s=0.0050 d_backcalc_s=0.0000':raise RuntimeError('Current tracking mismatch')
                            verified.add('tracking')
                        if s.startswith('CURRENT_ACTIVE '):
                            v=fields(s)
                            if any(abs(v.get(k,100)-x)>1e-7 for k,x in {'q_LPF_s':.001,'d_LPF_s':.001,'velocity_LPF_s':.005,'q_P':.6,'q_I':400}.items()):raise RuntimeError('Applied current/velocity configuration mismatch')
                            verified.add('active')
                        if s.startswith('RUN BENCH MOTION:'):
                            if verified!={'profile','motion','loop','tracking','active','observer','estimator'}:raise RuntimeError('Motion started without complete verified metadata')
                            if args.stop_after_ms is not None:stop_deadline=time.monotonic()+args.stop_after_ms/1000
                        if s.startswith('STOP: '):stopped=True
                        if s=='TRACE_END':trace=True
                        if stopped and re.match(r'^\d+,0,',s) and abs(float(s.split(',')[-1]))<1e-8:off+=1
                    if stopped and trace and off>=3:break
                else:raise RuntimeError('Missing STOP/whole trace/disabled telemetry; no retry')
                record('HOST completed: STOP + TRACE_END + disabled telemetry confirmed')
            finally:
                send(b's');record(f'HOST sent final s; test_command_sent={sent}');ack=False;end=time.monotonic()+2
                while time.monotonic()<end:
                    if 'STOP: serial stop' in read():ack=True;break
                record(f'HOST final_stop_acknowledged={ack}')
                if not ack:raise RuntimeError('Final stop acknowledgement missing')
            if args.stop_after_ms is not None:
                if not live_stop:raise RuntimeError('Scheduled stop did not run')
                send(command);end=time.monotonic()+2;rejected=False
                while time.monotonic()<end and not rejected:
                    for s in read():
                        if s=='Rejected: unavailable or already attempted; reset for another test.':rejected=True
                        if s.startswith(('ALIGNING:','RUN BENCH')):send(b's');raise RuntimeError('Same-boot drive lock failed')
                record(f'HOST drive_lock_verified={rejected}')
                if not rejected:raise RuntimeError('Missing drive lock rejection')
                send(b'c');end=time.monotonic()+2;gate=False
                while time.monotonic()<end and not gate:
                    for s in read():
                        if s.startswith('PWM '):gate=fields(s).get('gate_inputs_low')==1
                record(f'HOST gate_off_verified={gate}')
                if not gate:raise RuntimeError('Missing gate OFF confirmation')

if __name__=='__main__':main()
