#include <Arduino.h>
#include <SimpleFOC.h>
#include <ManualDiagnostics.h>
#include <RunEdgeCapture.h>
#include <WindowVelocity.h>
#include <MotionWatchdog.h>
#include <MagnitudeSlew.h>
#include <BoardCurrentObserver.h>
#include <ObservationGuard.h>
#include <PhasePulseProfile.h>
#include <BoundedBLDCMotor.h>
#include <ObserverCurrentSense.h>
#include <AbiQuality.h>
#include <PositionFeedforward.h>
#include <RollingVelocity.h>
#include <EdgeVelocity.h>
#include <ShortRunClock.h>
#include <CurrentProbe.h>
#include <AlignmentPlan.h>
#include <AdaptiveHarmonic.h>
#include <VelocityReference.h>
#include <GuardPeak.h>
#include <ReferenceSpeedGuard.h>
#include <IntervalVelocityStats.h>
#include <BenchCurrentPulse.h>
#include <BenchCurrentGuard.h>
#include <BenchJoint.h>
#include <BenchBrake.h>
#include <BenchMotion.h>
#include <BenchMotionStats.h>
#include <TraceSample.h>

constexpr int kDiagVersion = 174;
enum class CurrentTrial { none, fixed015, fixed025, velocity, velocityCompensated, velocityRolling, velocityProbe, staticProbe, staticProbe10, velocityFastIntegral, velocityReverse, velocityCoverage, velocityLongWindow, velocityLowerFilter, velocityDense, velocityDenseLowerP, velocityHigherI, velocityHigherIReverse, velocityStrongerI, velocityStrongerIReverse, velocityHigherIDense, velocityStrongerIDense, velocityAdaptive, velocityAdaptiveZero, velocityResponseProbe, velocityResponseProbeInverse, velocityAdaptiveFlat, velocityHigherP, velocitySpeed2, velocitySpeed2LowerI, velocitySpeed2LowerP, velocitySpeed3LowerP, velocitySpeed2LowerFilter, velocitySpeed25LowerFilter, velocitySpeed3LowerFilter, velocitySpeed25HalfFilter, velocitySpeed25Dense, velocitySpeed2Dense, velocitySpeed25Adaptive, velocitySpeed25AdaptiveZero, velocitySpeed3Adaptive, velocitySpeed25SlowRamp, velocitySpeed60, velocitySpeed60CurrentFilter, velocitySpeed60LowGain, velocitySpeed60ModerateI, velocitySpeed60Balanced, velocitySpeed60Damped, velocitySpeed60HalfCurrent, velocitySpeed60MidP, velocitySpeed60Edge, velocitySpeed60EdgeCycles, velocitySpeed60EdgeLowerP, velocitySpeed60EdgeFast, velocitySpeed60EdgeTracking, velocitySpeed60EdgeTrackingLowerP, velocitySpeed60EdgeTracking5, velocitySpeed60EdgeTracking5CurrentI, velocitySpeed60Response, velocitySpeed60ResponseInverse, velocitySpeed60Adaptive14, benchPulse05, benchPulse10, benchJointPositive, benchJointNegative, benchCoast, benchBrakeActive, benchMotionPositive, benchMotionNegative };
constexpr int kEncoderPpr = 1000; // Two measured index intervals: 4000 signed counts each.
constexpr int kMotorPolePairs = 7; // Motor datasheet: 12N14P.
constexpr float kBusVoltage = 11.1f;
constexpr float kVoltageLimit = 0.5f;
#ifndef BENCH_FAST_VOLTAGE_LIMIT
#define BENCH_FAST_VOLTAGE_LIMIT .5f
#endif
constexpr float kFastVoltageLimit=BENCH_FAST_VOLTAGE_LIMIT;
constexpr float kFastCurrentQLpfS=.0005f;
static_assert(kFastVoltageLimit==.5f || kFastVoltageLimit==.7f,"reviewed fast voltage levels only");
#ifndef BENCH_HIGH_SPEED_RPM
static_assert(kFastVoltageLimit==.5f,"higher fast voltage is forbidden for old small-angle trials");
#endif
constexpr float kAlignVoltage = 0.7f;
constexpr float kTargetVelocity = 1.0f; // rad/s, approximately 9.55 rpm.
constexpr float kOpenTargetVelocity = 1.0f; // Compare open-loop at the same nominal speed as closed-loop.
constexpr float kOpenVoltageLimit = 0.5f; // Match closed-loop voltage ceiling; alignment remains 0.7V.
constexpr float kVelocityOutputRamp = 3.0f; // Best tested closed-loop profile; symmetric V/s slew limit.
constexpr uint32_t kRunMs = 3000;
constexpr int kAlignCycles = AlignmentPlan::normalCycles;
constexpr int kAlignmentSampleStride = 10;
static_assert(2 * (500 * kAlignCycles / kAlignmentSampleStride + 1) + 3 <= 320,
              "Alignment samples must fit the existing run buffer");
#ifndef DIAG_PWM_HZ
#define DIAG_PWM_HZ 25000
#endif
constexpr long kPwmFrequency = DIAG_PWM_HZ;
static_assert(kPwmFrequency == 25000 || kPwmFrequency == 12500, "Only compared PWM profiles are supported");
// Keep requested dead time at 800ns when changing frequency, not a constant fraction.
constexpr float kPwmDeadZone = 0.02f * (kPwmFrequency / 25000.0f);
// Observe the existing velocity call without advancing its estimator twice.
class DiagnosticEncoder : public Encoder {
 public:
  using Encoder::Encoder;
  float rawVelocity = 0;
  float legacyFilteredVelocity = 0;
  float correctedVelocity = 0;
  WindowVelocity window;
  RollingVelocity rolling;
  EdgeVelocity edgeVelocity;
  bool useEdge=false,edgeDwtClock=false;
  uint32_t edgeClockOrigin=0;
  uint32_t edgeTimestamp() const {return edgeDwtClock ? ShortRunClock::elapsedUs(edgeClockOrigin,DWT->CYCCNT) : micros();}
  volatile bool edgeControlActive=false;
  bool useRolling = false;
  float guardVelocity = 0;
  uint32_t velocitySampleUs=0;
  bool velocitySampleValid=false;
  LowPassFilter guardFilter{.002f};
  LowPassFilter legacyFilter{0.05f};
  float getVelocity() override {
    rawVelocity = Encoder::getVelocity();
    legacyFilteredVelocity = legacyFilter(rawVelocity); // Diagnostic shadow only.
    const float angle = getAngle(); const uint32_t now = micros();
    velocitySampleUs=now;velocitySampleValid=true;
    const float windowValue = window.update(angle, now);
    if (!useRolling) return correctedVelocity = windowValue;
    guardVelocity = guardFilter(windowValue); // Original 2ms-window/2ms-LPF overspeed channel.
    if (useEdge && edgeControlActive) {
      const uint32_t mask=__get_PRIMASK();__disable_irq();
      const auto sample=edgeVelocity.snapshot();const uint32_t edgeNow=edgeTimestamp();
      __set_PRIMASK(mask);
      return correctedVelocity=edgeVelocity.update(sample,edgeNow);
    }
    return correctedVelocity = rolling.update(angle, now);
  }
};
DiagnosticEncoder encoder(PB6, PB7, kEncoderPpr); // No index search; align each boot.
BLDCDriver6PWM driver(PA8, PC13, PA9, PA12, PA10, PB15);
BoundedBLDCMotor motor(kMotorPolePairs);
volatile uint32_t edgesA = 0, edgesB = 0, indexPulses = 0;
struct IndexReference { uint32_t bootUs, pulse; float angle; };
volatile IndexReference indexReferences[8]{};
volatile uint8_t indexReferenceCount = 0;
AbiQuality abiQuality;
struct AbiSnapshot { int32_t count; uint32_t callbacks, invalid, duplicate, reversals; float encoderAngle; };
AbiSnapshot runAbiStart{}, runAbiEnd{};
bool ready = false, attempted = false, running = false;
bool openTest = false;
bool phasePulseTest = false;
bool currentIqTest = false;
bool currentVelocityTest = false;
bool benchDriveTest=false,benchAlignmentTest=false,benchTest=false,benchReported=false;
bool benchStartupPending=false;
uint32_t benchFirstPiElapsedUs=0;
bool benchPositionTest=false,benchBrakeTest=false,benchMotionTest=false;
BenchMotion benchMotion;
BenchMotionStats benchMotionStats;
BenchBrake benchBrake;
BenchJoint benchJoint;
float benchPulseAmplitude=0;
BenchCurrentGuard benchCurrentGuard;
bool alignmentRangeValid=false;
bool alignmentPullComplete=false;
float alignmentOrigin=0,alignmentMinimum=0,alignmentMaximum=0,alignmentAfterPull=0,alignmentPeakPhase=0;
bool currentHighSpeedTest=false,rawHighOpenTest=false;
float openVelocityGoal=kOpenTargetVelocity;
bool referenceSpeedGuardActive() {return currentHighSpeedTest || rawHighOpenTest;}
IntervalVelocityStats intervalVelocityStats;
bool currentFeedforwardTest = false;
bool currentProbeTest = false;
bool currentResponseProbeTest=false,currentResponseProbeInverseTest=false;
bool currentStaticProbeTest = false;
bool currentStaticProbe10Test = false;
bool currentFastIntegralTest = false;
bool currentReverseTest = false;
bool currentCoverageTest = false;
bool currentAdaptiveTest=false,currentAdaptiveZeroTest=false,currentAdaptiveFlatTest=false,currentSpeed25AdaptiveTest=false,currentSpeed3AdaptiveTest=false,currentSpeed60Adaptive14Test=false;
AdaptiveHarmonic adaptiveHarmonic,adaptiveHarmonicZero{0},adaptiveHarmonicFlat{.2f,.03f,0};
AdaptiveHarmonic adaptiveSpeed25{.2f,.03f,.7853981634f,2.5f},adaptiveSpeed25Zero{0,.03f,.7853981634f,2.5f};
AdaptiveHarmonic adaptiveSpeed3{.2f,.03f,.7853981634f,3};
AdaptiveHarmonic adaptiveSpeed60Order14{.2f,.01f,.7853981634f,6.2831853f,14};
AdaptiveHarmonic& activeAdaptive() {return currentSpeed60Adaptive14Test ? adaptiveSpeed60Order14 : currentSpeed3AdaptiveTest ? adaptiveSpeed3 : currentSpeed25AdaptiveTest ? (currentAdaptiveZeroTest ? adaptiveSpeed25Zero : adaptiveSpeed25) : currentAdaptiveZeroTest ? adaptiveHarmonicZero : currentAdaptiveFlatTest ? adaptiveHarmonicFlat : adaptiveHarmonic;}
const char* alignmentFailure=nullptr;
float currentVelocityGoal=kTargetVelocity;
uint32_t currentSpeedRampUs=0;
CurrentProbe currentProbe{20,.02f};
CurrentProbe responseCurrentProbe{17.5f,.02f};
CurrentProbe responseCurrentProbeInverse{17.5f,.02f,800000,200000,3.14159265f};
CurrentProbe staticCurrentProbe{20,.02f,400000,100000};
CurrentProbe staticCurrentProbe10{10,.02f,400000,100000};
CurrentProbe& activeCurrentProbe() { return currentResponseProbeTest ? (currentResponseProbeInverseTest ? responseCurrentProbeInverse : responseCurrentProbe) : currentStaticProbe10Test ? staticCurrentProbe10 : currentStaticProbeTest ? staticCurrentProbe : currentProbe; }
// Half the mean 84th-order equivalent-current coefficients independently fitted
// from window-age-02/04. Experimental hypothesis only; no absolute torque claim.
PositionFeedforward positionFeedforward{-.0085f, .0253f, .03f};
struct FeedforwardSample { uint32_t elapsedUs; float pid, correction, total; };
FeedforwardSample feedforwardTrace[16]{};
uint8_t feedforwardCount = 0;
uint32_t lastFeedforwardUs = 0;
bool alignmentOnlyTest = false;
uint16_t alignmentCount = 0;
uint32_t alignmentStartUs = 0;
float fixedIqGoal = 0;
bool asymmetricTest = false;
bool forwardOnlyTest = false;
float fixedUqTest = 0; // Nonzero only for the fixed-voltage, sensor-commutated diagnostic.
MagnitudeSlew magnitudeSlew{3.0f}; // Retain the tested low-reversal comparison profile.
float unslewedPidUq = 0;
float measuredVelocity = 0;
float lastGuardVelocity = 0, runGuardAbsPeak = 0;
GuardPeakTracker guardPeaks;
LowPassFilter observedVelocity(0.05f);
uint32_t runStart = 0;
float startAngle = 0;
constexpr uint32_t kTracePeriodUs = 10000;
uint32_t tracePeriodUs = kTracePeriodUs;
constexpr uint16_t kTraceCapacity = 320; // Entire 3s run, dumped only after disabling output.
TraceSample trace[kTraceCapacity];
uint16_t traceNext = 0, traceCount = 0;
uint32_t traceStartUs = 0, lastTraceUs = 0, lastLoopUs = 0, loopUs = 0;
uint32_t windowStartUs = 0;
float windowAngle = 0, windowVelocity = 0, commandedVelocity = 0;
bool tracePending = false;
MotionWatchdog motionWatchdog;
BoardCurrentObserver currentObserver;
bool observeCurrents = false;
BoardCurrentObserver::Frame observedFrame{};
ObserverCurrentSense observerSense(currentObserver, observedFrame);
struct CurrentControlTrace { float iq, id, ud, target; } currentControlTrace{};
ObservationGuard observationGuard;
bool senseIdle = false;
bool senseAttempted = false;
uint32_t senseLastReport = 0;
ManualDiagnostics manual;
RunEdgeCapture<ManualDiagnostics::Edge,ManualDiagnostics::capacity> runEdges{manual.edges};
bool rawEdgeTest=false;
bool manualLocked = false;
uint32_t manualLastReport = 0, manualWindowUs = 0;
float manualWindowAngle = 0, manualWindowVelocity = 0;
uint32_t manualIntegralUs = 0;
float manualStartAngle = 0;
double manualCorrectedIntegral = 0, manualFilteredIntegral = 0, manualLegacyIntegral = 0;
float previousCorrected = 0, previousFiltered = 0, previousLegacy = 0;

AbiSnapshot readAbiSnapshot() {
  const uint32_t mask = __get_PRIMASK(); __disable_irq();
  const AbiSnapshot result{abiQuality.count, abiQuality.callbacks, abiQuality.invalid,
      abiQuality.duplicate, abiQuality.reversals, encoder.getSensorAngle()};
  __set_PRIMASK(mask); return result;
}

void beginTrace() {
  traceNext = traceCount = 0;
  if (rawEdgeTest) encoder.edgeClockOrigin=DWT->CYCCNT;
  traceStartUs = lastTraceUs = lastLoopUs = windowStartUs = micros();
  windowAngle = encoder.getAngle();
  windowVelocity = commandedVelocity = 0;
  encoder.window.reset(encoder.getAngle(), micros());
  encoder.rolling.reset(encoder.getAngle(), micros());
  if (encoder.useEdge) {
    const uint32_t mask=__get_PRIMASK();__disable_irq();
    encoder.edgeClockOrigin=DWT->CYCCNT;
    encoder.edgeVelocity.reset(static_cast<uint32_t>(abiQuality.count));encoder.edgeControlActive=true;
    __set_PRIMASK(mask);
  }
  if (currentAdaptiveTest) activeAdaptive().reset(static_cast<int>(motor.sensor_direction)*encoder.getAngle(),micros());
  encoder.guardVelocity = lastGuardVelocity = runGuardAbsPeak = 0;
  encoder.velocitySampleValid=false;guardPeaks.reset(currentSpeedRampUs>800000 ? currentSpeedRampUs : 800000);
  if (referenceSpeedGuardActive()) intervalVelocityStats.reset(traceStartUs,currentVelocityGoal,currentSpeedRampUs);
  motionWatchdog.reset(encoder.getAngle(), micros());
  magnitudeSlew.reset(micros());
  unslewedPidUq = 0;
  currentControlTrace = {};
  if (currentVelocityTest || currentStaticProbeTest) motor.actuatorStats.reset(micros(),currentStaticProbeTest ? 500000 : 800000);
  if (rawEdgeTest) {
    const uint32_t mask=__get_PRIMASK();__disable_irq();
    runAbiStart=readAbiSnapshot();runEdges.begin(runAbiStart.count,abiQuality.currentState());
    __set_PRIMASK(mask);
  } else runAbiStart = readAbiSnapshot();
  loopUs = 0;
}

void recordTrace(bool force, float uq) {
  const uint32_t now = micros();
  if (!force && now - lastTraceUs < tracePeriodUs) return;
  lastTraceUs = now;
  noInterrupts();
  const uint32_t a = edgesA, b = edgesB;
  interrupts();
  const uint32_t adcAge = observeCurrents ? micros() - observedFrame.us : 0;
  const uint32_t windowAge = now - windowStartUs;
  trace[traceNext] = {now - traceStartUs,
      static_cast<uint16_t>(loopUs > 65535 ? 65535 : loopUs),
      static_cast<uint16_t>(windowAge > 65535 ? 65535 : windowAge), a, b,
      encoder.getAngle(), {encoder.rawVelocity}, measuredVelocity,
      windowVelocity, {rawHighOpenTest ? openVelocityGoal : commandedVelocity}, uq, {openTest ? motor.shaft_angle : 0.0f},
      {asymmetricTest ? unslewedPidUq : 0.0f},
      observeCurrents ? observedFrame.adc1Frames : 0, observeCurrents ? observedFrame.adc2Frames : 0,
      static_cast<uint16_t>(adcAge > 65535 ? 65535 : adcAge),
      static_cast<uint16_t>(observeCurrents ? observedFrame.a : 0), static_cast<uint16_t>(observeCurrents ? observedFrame.b : 0),
      static_cast<uint16_t>(observeCurrents ? observedFrame.c : 0), static_cast<uint16_t>(observeCurrents ? observedFrame.vbus : 0),
      static_cast<uint16_t>(observeCurrents ? observedFrame.temperature : 0)};
  if (currentIqTest) {
    trace[traceNext].iqFiltered = currentControlTrace.iq;
    trace[traceNext].idFiltered = currentControlTrace.id;
    trace[traceNext].ud = currentControlTrace.ud;
    trace[traceNext].iqTarget = currentControlTrace.target;
  }
  if (benchDriveTest) trace[traceNext].temperatureAdc=(trace[traceNext].temperatureAdc&4095u) |
      (motor.lastVectorLimited ? 4096u:0u) | (motor.lastSlewLimited ? 8192u:0u);
  if (benchPositionTest) {
    if(benchMotionTest ? benchMotion.holdingBand:benchJoint.holdingBand)trace[traceNext].temperatureAdc|=16384u;
    trace[traceNext].jointTarget=benchMotionTest ? benchMotion.targetJoint:benchJoint.targetJoint;
    trace[traceNext].jointVelocityTarget=benchMotionTest ? benchMotion.velocityTarget:benchJoint.velocityTarget;
  }
  if (benchBrakeTest) {
    trace[traceNext].a=benchBrake.phase;trace[traceNext].b=benchBrake.transitionUs;
    trace[traceNext].windowVelocity=encoder.guardVelocity*static_cast<int>(motor.sensor_direction);
    if(BoardCurrentObserver::gatesOff())trace[traceNext].temperatureAdc|=16384u;
  }
  traceNext = (traceNext + 1) % kTraceCapacity;
  if (traceCount < kTraceCapacity) ++traceCount;
}

void reportIndexReferences() {
  const auto quality = readAbiSnapshot();
  Serial.print("ABI_QUALITY callbacks="); Serial.print(quality.callbacks);
  Serial.print(" invalid="); Serial.print(quality.invalid);
  Serial.print(" duplicate="); Serial.print(quality.duplicate);
  Serial.print(" net_signed_count="); Serial.println(quality.count);
  if (traceCount && !alignmentOnlyTest) {
    Serial.print("ABI_QUALITY_RUN callbacks="); Serial.print(runAbiEnd.callbacks-runAbiStart.callbacks);
    Serial.print(" invalid="); Serial.print(runAbiEnd.invalid-runAbiStart.invalid);
    Serial.print(" duplicate="); Serial.print(runAbiEnd.duplicate-runAbiStart.duplicate);
    Serial.print(" reversals="); Serial.print(runAbiEnd.reversals-runAbiStart.reversals);
    Serial.print(" count_delta="); Serial.print(runAbiEnd.count-runAbiStart.count);
    Serial.print(" encoder_count_delta="); Serial.println((runAbiEnd.encoderAngle-runAbiStart.encoderAngle)*4000/_2PI, 3);
  }
  const uint8_t count = indexReferenceCount; // ISR publishes count after writing each immutable slot.
  if (!count) Serial.println("INDEX_REFERENCE none_observed=1");
  for (uint8_t n = 0; n < count; ++n) {
    Serial.print("INDEX_REFERENCE pulse="); Serial.print(indexReferences[n].pulse);
    Serial.print(" boot_us="); Serial.print(indexReferences[n].bootUs);
    Serial.print(" encoder_angle_rad="); Serial.println(indexReferences[n].angle, 6);
  }
}

void dumpTrace() {
  tracePending = false;
  Serial.println("TRACE_BEGIN: outputs disabled; velocities use encoder sign except closed-loop filtered velocity.");
  Serial.print("trace_us,loop_us,A_edges,B_edges,angle_rad,raw_rad_s,filtered_rad_s,window10ms_rad_s,target_rad_s,Uq_V,open_field_mechanical_rad,unslewed_pid_uq_V,adc1_frames,adc2_frames,adc_age_us,ia_adc,ib_adc,ic_adc,vbus_adc,temp_adc,Ud_V,iq_target_nominal_A,iq_filtered_nominal_A,id_filtered_nominal_A,window_age_us");
  Serial.println(benchBrakeTest ? ",bench_flags,brake_phase,brake_start_us,guard_velocity_rad_s" : benchPositionTest ? ",bench_flags,joint_target_rad,joint_measured_rad,joint_velocity_rad_s,joint_velocity_target_rad_s" : benchDriveTest ? ",bench_flags" : "");
  for (uint16_t n = 0; n < traceCount; ++n) {
    const TraceSample& row = trace[(traceNext + kTraceCapacity - traceCount + n) % kTraceCapacity];
    Serial.print(row.elapsedUs); Serial.print(',');
    Serial.print(row.loopUs); Serial.print(',');
    Serial.print(benchPositionTest || benchBrakeTest ? 0:row.a); Serial.print(','); Serial.print(benchPositionTest || benchBrakeTest ? 0:row.b); Serial.print(',');
    Serial.print(row.angle, 6); Serial.print(',');
    Serial.print(currentIqTest ? 0.0f : row.rawVelocity, 6); Serial.print(',');
    Serial.print(row.filteredVelocity, 6); Serial.print(',');
    Serial.print(benchBrakeTest ? 0:row.windowVelocity, 6); Serial.print(',');
    Serial.print(currentIqTest ? (currentVelocityTest ? currentVelocityGoal : 0.0f) : row.target, 6); Serial.print(','); Serial.print(row.uq, 4); Serial.print(',');
    Serial.print(currentIqTest ? 0.0f : row.openFieldAngle, 6); Serial.print(','); Serial.print(currentIqTest ? 0.0f : row.unslewedUq, 6); Serial.print(',');
    Serial.print(row.adc1Frames); Serial.print(','); Serial.print(row.adc2Frames); Serial.print(','); Serial.print(row.adcAge); Serial.print(',');
    Serial.print(row.iaAdc); Serial.print(','); Serial.print(row.ibAdc); Serial.print(','); Serial.print(row.icAdc); Serial.print(',');
    Serial.print(row.vbusAdc); Serial.print(','); Serial.print(benchDriveTest ? row.temperatureAdc&4095u : row.temperatureAdc); Serial.print(',');
    Serial.print(currentIqTest ? row.ud : 0.0f, 6); Serial.print(',');
    Serial.print(currentIqTest ? row.iqTarget : 0.0f, 6); Serial.print(',');
    Serial.print(currentIqTest ? row.iqFiltered : 0.0f, 6); Serial.print(',');
    Serial.print(currentIqTest ? row.idFiltered : 0.0f, 6); Serial.print(',');
    Serial.print(row.windowAgeUs);
    if (benchDriveTest) {Serial.print(',');Serial.print(row.temperatureAdc>>12);}
    if (benchPositionTest) {
      Serial.print(',');Serial.print(row.jointTarget,6);Serial.print(',');Serial.print(static_cast<int>(motor.sensor_direction)*(row.angle-startAngle)/8,6);
      Serial.print(',');Serial.print(row.filteredVelocity/8,6);Serial.print(',');Serial.print(row.jointVelocityTarget,6);
    }
    if (benchBrakeTest) {
      Serial.print(',');Serial.print(row.a);Serial.print(',');Serial.print(row.b);
      Serial.print(',');Serial.print(row.windowVelocity,6);
    }
    Serial.println();
  }
  Serial.println("TRACE_END");
  reportIndexReferences();
  if (currentProbeTest) {
    const auto& probe=activeCurrentProbe();
    Serial.print("CURRENT_PROBE_SUMMARY calls="); Serial.print(probe.calls);
    Serial.print(" clipped_calls="); Serial.print(probe.clipped);
    Serial.print(" peak_nominal_A="); Serial.print(probe.peak,6);
    Serial.print(" invalid="); Serial.println(probe.invalid ? 1 : 0);
    Serial.println("CURRENT_PROBE_SAMPLES elapsed_us,pid_nominal_A,probe_nominal_A,total_nominal_A");
    for (uint8_t n=0;n<feedforwardCount;++n) {
      const auto& row=feedforwardTrace[n];
      Serial.print(row.elapsedUs);Serial.print(',');Serial.print(row.pid,6);Serial.print(',');
      Serial.print(row.correction,6);Serial.print(',');Serial.println(row.total,6);
    }
  }
  if (currentFeedforwardTest) {
    Serial.print("CURRENT_FF_SUMMARY seen_indices="); Serial.print(positionFeedforward.seenIndices);
    Serial.print(" armed="); Serial.print(positionFeedforward.armed ? 1 : 0);
    Serial.print(" active_calls="); Serial.print(positionFeedforward.activeCalls);
    Serial.print(" peak_requested_A="); Serial.print(positionFeedforward.maxRequested, 6);
    Serial.print(" invalid="); Serial.println(positionFeedforward.invalid ? 1 : 0);
    Serial.println("CURRENT_FF_SAMPLES elapsed_us,pid_nominal_A,correction_nominal_A,total_nominal_A");
    for (uint8_t n = 0; n < feedforwardCount; ++n) {
      const auto& row = feedforwardTrace[n];
      Serial.print(row.elapsedUs); Serial.print(','); Serial.print(row.pid, 6); Serial.print(',');
      Serial.print(row.correction, 6); Serial.print(','); Serial.println(row.total, 6);
    }
  }
  if (currentAdaptiveTest) {
    const auto& adaptive=activeAdaptive();
    Serial.print("ADAPTIVE_SUMMARY calls=");Serial.print(adaptive.calls);
    Serial.print(" learned_calls=");Serial.print(adaptive.learned);
    Serial.print(" clipped_calls=");Serial.print(adaptive.clipped);
    Serial.print(" cosine_nominal_A=");Serial.print(adaptive.cosineA,6);
    Serial.print(" sine_nominal_A=");Serial.print(adaptive.sineA,6);
    Serial.print(" peak_nominal_A=");Serial.print(adaptive.peakA,6);
    Serial.print(" invalid=");Serial.println(adaptive.invalid ? 1 : 0);
    Serial.println("ADAPTIVE_SAMPLES elapsed_us,pid_nominal_A,correction_nominal_A,total_nominal_A");
    for (uint8_t n=0;n<feedforwardCount;++n) {
      const auto& row=feedforwardTrace[n];
      Serial.print(row.elapsedUs);Serial.print(',');Serial.print(row.pid,6);Serial.print(',');
      Serial.print(row.correction,6);Serial.print(',');Serial.println(row.total,6);
    }
  }
}
void reportPwm() {
  Serial.print("PWM hz="); Serial.print(kPwmFrequency);
  Serial.print(" dead_zone="); Serial.print(kPwmDeadZone, 6);
  Serial.print(" system_clock_Hz="); Serial.print(SystemCoreClock);
  Serial.print(" tim1_cr1="); Serial.print(TIM1->CR1);
  Serial.print(" tim1_psc="); Serial.print(TIM1->PSC);
  Serial.print(" tim1_arr="); Serial.print(TIM1->ARR);
  Serial.print(" tim1_bdtr="); Serial.print(TIM1->BDTR);
  Serial.print(" rcc_cfgr="); Serial.print(RCC->CFGR);
  Serial.print(" gate_inputs_low="); Serial.println(BoardCurrentObserver::gatesOff() ? 1 : 0);
  Serial.print("FIRMWARE diag_version="); Serial.println(kDiagVersion);
}
uint8_t abiState() { return AbiQuality::stateFromPort(GPIOB->IDR); }
void onA() {
  ++edgesA;
  const uint8_t state = abiState(); abiQuality.edge(state);
  if (encoder.edgeControlActive) encoder.edgeVelocity.edge(static_cast<uint32_t>(abiQuality.count),encoder.edgeTimestamp());
  if (runEdges.active) runEdges.edge(encoder.edgeTimestamp(),abiQuality.count,state);
  if (manual.active) manual.edge(state);
  encoder.handleA();
}
void onB() {
  ++edgesB;
  const uint8_t state = abiState(); abiQuality.edge(state);
  if (encoder.edgeControlActive) encoder.edgeVelocity.edge(static_cast<uint32_t>(abiQuality.count),encoder.edgeTimestamp());
  if (runEdges.active) runEdges.edge(encoder.edgeTimestamp(),abiQuality.count,state);
  if (manual.active) manual.edge(state);
  encoder.handleB();
}
void onIndex() {
  ++indexPulses;
  const uint8_t slot = indexReferenceCount;
  if (slot < 8) {
    // Public accessor is one atomic 32-bit counter read plus float scaling;
    // do not call update()/handleIndex(), which would alter interrupt/counter state.
    indexReferences[slot].angle = encoder.getSensorAngle();
    indexReferences[slot].bootUs = micros();
    indexReferences[slot].pulse = indexPulses;
    indexReferenceCount = slot + 1;
  }
  manual.index(edgesA, edgesB);
}

void endManual() {
  noInterrupts();
  const bool wasActive = manual.active;
  manual.active = false;
  interrupts();
  if (wasActive) {
    Serial.print("MANUAL_INTEGRALS angle_rad,corrected_input_rad,filtered_rad,legacy_filtered_rad: ");
    Serial.print(encoder.getAngle() - manualStartAngle, 6); Serial.print(',');
    Serial.print(manualCorrectedIntegral, 6); Serial.print(',');
    Serial.print(manualFilteredIntegral, 6); Serial.print(','); Serial.println(manualLegacyIntegral, 6);
    manual.dump(Serial);
  }
}

void startManual() {
  if (running || manual.active || runEdges.busy()) {
    Serial.println("Rejected: stop current operation before manual capture.");
    return;
  }
  if (ready) driver.disable();
  attempted = manualLocked = true;
  encoder.update();
  encoder.useRolling = false; encoder.window.periodUs = 10000;
  encoder.window.reset(encoder.getAngle(), micros());
  manualWindowAngle = encoder.getAngle();
  manualWindowUs = micros();
  manualIntegralUs = manualWindowUs;
  manualStartAngle = manualWindowAngle;
  manualCorrectedIntegral = manualFilteredIntegral = manualLegacyIntegral = 0;
  previousCorrected = previousFiltered = previousLegacy = 0;
  manualLastReport = millis();
  noInterrupts();
  manual.begin(abiState());
  interrupts();
  Serial.println("MANUAL_BEGIN: gates OFF; all drive commands locked until reset; x=end capture.");
  Serial.println("CONFIG encoder_ppr=1000 counts_per_turn=4000 estimator=window10ms; raw=legacy_shadow");
  reportPwm();
  Serial.println("MANUAL ms,angle_rad,raw_rad_s,filtered_rad_s,window_rad_s,signed_count,invalid,duplicate,reversals,A_edges,B_edges,index");
}

void startSenseIdle() {
  if (running || manual.active || senseAttempted) {
    Serial.println("Rejected: sense init requires idle and one initialization per boot.");
    return;
  }
  if (ready) motor.disable();
  senseAttempted = true;
  attempted = manualLocked = true;
  Serial.println("SENSE_BEGIN: gates OFF; all drive commands locked; initialize ADC observer only.");
  const bool ok = ready && currentObserver.beginDisabled(driver);
  if (ready) driver.disable();
  senseIdle = ok;
  Serial.print("SENSE_INIT ready="); Serial.print(ok ? 1 : 0);
  Serial.print(" gates_off="); Serial.println(BoardCurrentObserver::gatesOff() ? 1 : 0);
  reportPwm();
  if (!ok) return;
  Serial.print("SENSE_OFFSETS_ADC ");
  for (int n = 0; n < 3; ++n) { if (n) Serial.print(','); Serial.print(currentObserver.offset[n], 3); }
  Serial.println();
  Serial.println("SENSE_CONFIG shunt_ohm=.003 gain=-64/7 ADC_ref_V=3.3_nominal VBUS_divider=187/18; no current control or current limit.");
  Serial.println("SENSE ms,adc1_frames,adc2_frames,age_us,a_adc,b_adc,c_adc,vbus_adc,temp_adc,ia_est_A,ib_est_A,ic_est_A,vbus_est_V,gates_off");
}

void reportSenseIdle() {
  if (!senseIdle || millis() - senseLastReport < 200) return;
  senseLastReport = millis();
  const auto frame = currentObserver.read();
  const uint32_t age = micros() - frame.us;
  if (age > 2000 || !BoardCurrentObserver::gatesOff()) {
    if (ready) driver.disable();
    senseIdle = false;
    Serial.println("SENSE_FAULT: stale ADC or gates not OFF; drive locked.");
    return;
  }
  Serial.print("SENSE,"); Serial.print(senseLastReport); Serial.print(',');
  Serial.print(frame.adc1Frames); Serial.print(','); Serial.print(frame.adc2Frames); Serial.print(','); Serial.print(age); Serial.print(',');
  Serial.print(frame.a); Serial.print(','); Serial.print(frame.b); Serial.print(','); Serial.print(frame.c); Serial.print(',');
  Serial.print(frame.vbus); Serial.print(','); Serial.print(frame.temperature); Serial.print(',');
  Serial.print(currentObserver.current(frame.a, 0), 4); Serial.print(',');
  Serial.print(currentObserver.current(frame.b, 1), 4); Serial.print(',');
  Serial.print(currentObserver.current(frame.c, 2), 4); Serial.print(',');
  Serial.print(BoardCurrentObserver::busVoltage(frame.vbus), 4); Serial.println(",1");
}

void reportManual() {
  const uint32_t now = micros();
  const double integralDt = (now - manualIntegralUs) * 1e-6;
  manualCorrectedIntegral += (previousCorrected + encoder.correctedVelocity) * 0.5 * integralDt;
  manualFilteredIntegral += (previousFiltered + measuredVelocity) * 0.5 * integralDt;
  manualLegacyIntegral += (previousLegacy + encoder.legacyFilteredVelocity) * 0.5 * integralDt;
  manualIntegralUs = now;
  previousCorrected = encoder.correctedVelocity;
  previousFiltered = measuredVelocity;
  previousLegacy = encoder.legacyFilteredVelocity;
  if (now - manualWindowUs >= 10000) {
    const float angle = encoder.getAngle();
    manualWindowVelocity = (angle - manualWindowAngle) * 1e6f / (now - manualWindowUs);
    manualWindowAngle = angle;
    manualWindowUs = now;
  }
  if (millis() - manualLastReport < 20) return;
  manualLastReport = millis();
  noInterrupts();
  const int32_t count = manual.count;
  const uint32_t invalid = manual.invalid, duplicate = manual.duplicate, reversals = manual.reversals;
  const uint32_t a = edgesA, b = edgesB, index = indexPulses;
  interrupts();
  Serial.print("MANUAL,"); Serial.print(manualLastReport); Serial.print(',');
  Serial.print(encoder.getAngle(), 6); Serial.print(',');
  Serial.print(encoder.rawVelocity, 6); Serial.print(',');
  Serial.print(measuredVelocity, 6); Serial.print(',');
  Serial.print(manualWindowVelocity, 6); Serial.print(','); Serial.print(count); Serial.print(',');
  Serial.print(invalid); Serial.print(','); Serial.print(duplicate); Serial.print(',');
  Serial.print(reversals); Serial.print(','); Serial.print(a); Serial.print(',');
  Serial.print(b); Serial.print(','); Serial.println(index);
}

void reportGuardPeak(const char* scope,const GuardPeakState& state,bool valid) {
  Serial.print("GUARD_PEAK scope=");Serial.print(scope);
  Serial.print(" valid=");Serial.print(valid ? 1 : 0);
  if (!valid) {Serial.println();return;}
  Serial.print(" elapsed_us=");Serial.print(state.elapsedUs);
  Serial.print(" sample_age_us=");Serial.print(state.sampleAgeUs);
  Serial.print(" adc_age_us=");Serial.print(state.adcAgeUs);
  Serial.print(" guard_rad_s=");Serial.print(state.guard,6);
  Serial.print(" control_rad_s=");Serial.print(state.control,6);
  Serial.print(" reference_rad_s=");Serial.print(state.reference,6);
  Serial.print(" iq_applied_nominal_A=");Serial.print(state.iqApplied,6);
  Serial.print(" iq_next_nominal_A=");Serial.print(state.iqNext,6);
  Serial.print(" iq_filtered_nominal_A=");Serial.print(state.iqFiltered,6);
  Serial.print(" Uq_V=");Serial.print(state.uq,6);
  Serial.print(" Ud_V=");Serial.print(state.ud,6);
  Serial.print(" correction_nominal_A=");Serial.println(state.correction,6);
}

void reportIntervalVelocityStats() {
  const auto& stats=intervalVelocityStats;
  const bool valid=!stats.invalid && stats.samples>0 && stats.coveredUs>0;
  Serial.print("VELOCITY_STATS valid=");Serial.print(valid ? 1 : 0);
  Serial.print(" invalid=");Serial.print(stats.invalid ? 1 : 0);
  Serial.print(" samples=");Serial.print(stats.samples);
  if (!valid) {Serial.println();return;}
  Serial.print(" first_elapsed_us=");Serial.print(stats.firstUs-stats.startUs);
  Serial.print(" last_elapsed_us=");Serial.print(stats.lastUs-stats.startUs);
  Serial.print(" covered_us=");Serial.print(stats.coveredUs);
  Serial.print(" displacement_rad=");Serial.print(stats.lastAngle-stats.firstAngle,6);
  Serial.print(" mean_motor_rad_s=");Serial.print(stats.mean(),6);
  Serial.print(" rms_error_rad_s=");Serial.print(stats.rmsError(),6);
  Serial.print(" minimum_rad_s=");Serial.print(stats.minimum,6);
  Serial.print(" maximum_rad_s=");Serial.print(stats.maximum,6);
  Serial.print(" slow_fraction=");Serial.print(stats.slowUs/static_cast<float>(stats.coveredUs),6);
  Serial.print(" reverse_fraction=");Serial.println(stats.reverseUs/static_cast<float>(stats.coveredUs),6);
}

void dumpRunEdges() {
  if (!runEdges.pending) return;
  if (running || !BoardCurrentObserver::gatesOff()) {Serial.println("ERROR: raw edge dump requires gates OFF");return;}
  Serial.print("RUN_EDGE_SUMMARY total_edges=");Serial.print(runEdges.total);
  Serial.print(" retained=");Serial.print(runEdges.size);
  Serial.print(" origin_count=");Serial.print(runEdges.originCount);
  Serial.print(" origin_AB=");Serial.print(runEdges.originState);
  Serial.print(" end_count=");Serial.print(runEdges.endCount);
  Serial.print(" end_us=");Serial.println(runEdges.endUs);
  Serial.println("RUN_EDGES_BEGIN: gates OFF; frozen manual storage; elapsed DWT microseconds");
  Serial.println("edge_us,signed_count,AB_state");
  ManualDiagnostics::Edge row{};
  for (uint16_t n=0;n<runEdges.size;++n) {
    if (!runEdges.read(n,row)) {Serial.println("ERROR: frozen raw edge unavailable");return;}
    Serial.print(row.us);Serial.print(',');Serial.print(row.count);Serial.print(',');Serial.println(row.state);
  }
  Serial.println("RUN_EDGES_END");
  runEdges.release();
}

void stopMotor(const char* reason) {
  const bool wasRunning = running;
  const uint32_t stoppedElapsedUs = micros() - traceStartUs;
  const float stoppedDisplacement = encoder.getAngle() - startAngle;
  const float stoppedUq = motor.voltage.q;
  motor.actuatorStats.armed = false;
  if (wasRunning && runEdges.active) {
    const uint32_t mask=__get_PRIMASK();__disable_irq();
    runEdges.freeze(encoder.edgeTimestamp(),abiQuality.count);runAbiEnd=readAbiSnapshot();
    __set_PRIMASK(mask);
  } else if (wasRunning) runAbiEnd = readAbiSnapshot();
  encoder.edgeControlActive=false;
  if (ready) motor.disable();
  running = false;
  if (wasRunning) {
    recordTrace(true, stoppedUq);
    tracePending = true;
  }
  Serial.print("STOP: "); Serial.println(reason);
  if (benchTest && !benchReported) {
    benchReported=true;
    if (alignmentRangeValid) {
      Serial.print("BENCH_ALIGNMENT origin_motor_rad=");Serial.print(alignmentOrigin,6);
      Serial.print(" initial_pull_complete=");Serial.print(alignmentPullComplete ? 1:0);
      Serial.print(" initial_pull_motor_rad=");Serial.print(alignmentAfterPull-alignmentOrigin,6);
      Serial.print(" minimum_delta_motor_rad=");Serial.print(alignmentMinimum-alignmentOrigin,6);
      Serial.print(" maximum_delta_motor_rad=");Serial.print(alignmentMaximum-alignmentOrigin,6);
      Serial.print(" peak_phase_nominal_A=");Serial.println(alignmentPeakPhase,6);
    }
    Serial.print("BENCH_CURRENT_STATUS fault=");Serial.print(static_cast<int>(benchCurrentGuard.fault));
    Serial.print(" peak_phase_nominal_A=");Serial.print(benchCurrentGuard.peakPhase,6);
    Serial.print(" peak_iq_nominal_A=");Serial.print(benchCurrentGuard.peakIq,6);
    Serial.print(" peak_id_nominal_A=");Serial.println(benchCurrentGuard.peakId,6);
    Serial.print("BENCH_STARTUP first_pi_elapsed_us=");Serial.println(benchFirstPiElapsedUs);
    if(benchMotionTest){
      Serial.print("MOTION_STATUS independent_peak_rad_s=");Serial.println(runGuardAbsPeak,6);
#ifdef BENCH_HIGH_SPEED_RPM
      Serial.print("FAST_MOTION_STATUS control_updates=");Serial.print(benchMotion.controlUpdates);
      Serial.print(" max_control_gap_us=");Serial.print(benchMotion.maxControlGap);
      Serial.print(" fault=");Serial.println(static_cast<int>(benchMotion.fault));
#endif
      for(unsigned p=0;p<2;++p){const auto& v=benchMotionStats.segments[p];
        Serial.print("MOTION_STATS phase=");Serial.print(p==0 ? 1:3);Serial.print(" samples=");Serial.print(v.samples);
        Serial.print(" max_error_joint_rad=");Serial.print(v.maxError,7);Serial.print(" error_square=");Serial.print(v.errorSquare,9);
        Serial.print(" iq_error_square=");Serial.print(v.iqErrorSquare,7);Serial.print(" peak_velocity_motor_rad_s=");Serial.print(v.peakVelocity,6);
        Serial.print(" vector_limited=");Serial.print(v.limited);Serial.print(" slew_limited=");Serial.print(v.slew);
        Serial.print(" near_iq_limit=");Serial.print(v.nearCurrent);Serial.print(" max_vector_V=");Serial.print(v.maxVector,6);
        Serial.print(" vbus_min_V=");Serial.print(v.minBus,5);Serial.print(" vbus_max_V=");Serial.println(v.maxBus,5);
      }
    }
    if (benchBrakeTest) {
      Serial.print("BENCH_BRAKE_STATUS phase=");Serial.print(benchBrake.phase);
      Serial.print(" transition_us=");Serial.print(benchBrake.transitionUs);
      Serial.print(" start_velocity_rad_s=");Serial.print(benchBrake.startVelocity,6);
      Serial.print(" start_guard_rad_s=");Serial.print(benchBrake.startGuard,6);
      Serial.print(" released=");Serial.print(benchBrake.released ? 1:0);
      Serial.print(" negative_target_us=");Serial.print(benchBrake.negativeTargetUs);
      Serial.print(" negative_current_us=");Serial.print(benchBrake.negativeCurrentUs);
      Serial.print(" invalid=");Serial.println(benchBrake.invalid ? 1:0);
    }
  }
  if (wasRunning) {
    Serial.print("RUN_REFERENCE start_angle_rad="); Serial.print(startAngle, 6);
    Serial.print(" zero_electric_angle_rad="); Serial.print(motor.zero_electric_angle, 6);
    Serial.print(" sensor_direction="); Serial.print(static_cast<int>(motor.sensor_direction));
    Serial.print(" open_field_start_rad="); Serial.println(openTest ? _3PI_2 / kMotorPolePairs : 0.0f, 6);
    Serial.print("RUN_SUMMARY elapsed_us,displacement_rad: ");
    Serial.print(stoppedElapsedUs); Serial.print(','); Serial.println(stoppedDisplacement, 6);
    Serial.print("STOP_DETAIL elapsed_us,filtered_rad_s,raw_rad_s,window10ms_rad_s: ");
    Serial.print(stoppedElapsedUs); Serial.print(',');
    Serial.print(measuredVelocity, 6); Serial.print(',');
    Serial.print(encoder.rawVelocity, 6); Serial.print(',');
    Serial.println(windowVelocity, 6);
    if (currentVelocityTest || currentStaticProbeTest) {
      Serial.print("STOP_GUARD source="); Serial.print(encoder.useRolling ? "original_window2ms_LPF2ms_shadow" : "controller_filtered_velocity");
      Serial.print(" last_observed_rad_s="); Serial.print(lastGuardVelocity, 6);
      Serial.print(" run_abs_peak_rad_s="); Serial.println(runGuardAbsPeak, 6);
      reportGuardPeak("whole",guardPeaks.whole,guardPeaks.wholeValid);
      reportGuardPeak("after_ramp",guardPeaks.steady,guardPeaks.steadyValid);
      if (encoder.useEdge) {
        const auto sample=encoder.edgeVelocity.snapshot();
        Serial.print("EDGE_ESTIMATOR_SUMMARY invalid=");Serial.print(sample.invalid ? 1:0);
        Serial.print(" samples=");Serial.print(sample.size);
        Serial.print(" signed_count=");Serial.print(static_cast<int32_t>(sample.count));
        Serial.print(" span_us=");Serial.println(sample.size>1 ? sample.times[sample.size-1]-sample.times[0] : 0);
        Serial.print("EDGE_CLOCK_FAULT reason=");Serial.print(static_cast<int>(encoder.edgeVelocity.fault));
        Serial.print(" now_us=");Serial.print(encoder.edgeVelocity.diagnosticNow);
        Serial.print(" edge_us=");Serial.print(encoder.edgeVelocity.diagnosticEdge);
        Serial.print(" age_us=");Serial.print(encoder.edgeVelocity.diagnosticAge);
        Serial.print(" update_gap_us=");Serial.println(encoder.edgeVelocity.diagnosticGap);
      }
      if (currentHighSpeedTest) reportIntervalVelocityStats();
      const auto& stats=motor.actuatorStats;
      Serial.print("CURRENT_ACTUATOR_STATS start_us="); Serial.print(stats.ignoreStartupUs);
      Serial.print(" covered_us="); Serial.print(stats.coveredUs);
      Serial.print(" calls="); Serial.print(stats.calls);
      const float duration=stats.coveredUs*1e-6f;
      Serial.print(" q_slew_limited_fraction="); Serial.print(stats.coveredUs ? stats.slewUs/static_cast<float>(stats.coveredUs) : 0, 6);
      Serial.print(" q_vector_limited_fraction="); Serial.print(stats.coveredUs ? stats.vectorUs/static_cast<float>(stats.coveredUs) : 0, 6);
      Serial.print(" mean_q_error_nominal_A="); Serial.print(duration ? stats.errorIntegral/duration : 0, 6);
      Serial.print(" rms_q_error_nominal_A="); Serial.print(duration ? sqrtf(stats.errorSquaredIntegral/duration) : 0, 6);
      Serial.print(" mean_requested_minus_applied_q_V="); Serial.print(duration ? stats.differenceIntegral/duration : 0, 6);
      Serial.print(" max_requested_applied_q_difference_V="); Serial.println(stats.maxDifference, 6);
    }
  }
  if (wasRunning && rawHighOpenTest) {
    Serial.print("STOP_GUARD source=original_window2ms_LPF2ms_shadow last_observed_rad_s=");Serial.print(lastGuardVelocity,6);
    Serial.print(" run_abs_peak_rad_s=");Serial.println(runGuardAbsPeak,6);
    reportIntervalVelocityStats();
  }
  dumpRunEdges();
}

const char* observationFaultReason() {
  return benchTest && benchCurrentGuard.fault!=BenchCurrentGuard::none ? benchCurrentGuard.reason() : ObservationGuard::reason(observationGuard.fault);
}

bool updateObservedFrame() {
  if (!observeCurrents) return true;
  observedFrame = currentObserver.read();
  const uint32_t now = micros();
  if (observationGuard.check(now, now - observedFrame.us,
      static_cast<int32_t>(observedFrame.adc2Frames - observedFrame.adc1Frames),
      observedFrame.a, observedFrame.b, observedFrame.c, BoardCurrentObserver::busVoltage(observedFrame.vbus)) != ObservationGuard::none) return false;
  return !benchTest || benchCurrentGuard.check(now,observedFrame.adc1Frames,
      currentObserver.current(observedFrame.a,0),currentObserver.current(observedFrame.b,1),currentObserver.current(observedFrame.c,2),
      motor.current.q,motor.current.d,running);
}

// Let the rotor settle at both ends, rather than measuring during a fast sweep.
// Keep the same 0.5 electrical-radian pole-pair tolerance as SimpleFOC.
void recordAlignment(float commandAngle, uint32_t leg) {
  if (!alignmentOnlyTest || alignmentCount >= kTraceCapacity) return;
  // Reuse the run buffer: this command never performs the subsequent run.
  auto& row = trace[alignmentCount++];
  row.elapsedUs = micros() - alignmentStartUs;
  row.loopUs = leg;
  row.angle = encoder.getAngle(); row.openFieldAngle = commandAngle;
  row.iaAdc = observedFrame.a; row.ibAdc = observedFrame.b; row.icAdc = observedFrame.c;
  row.vbusAdc = observedFrame.vbus;
}

void dumpAlignment() {
  Serial.print("ALIGN_TRACE_CONFIG sample_step_stride="); Serial.print(kAlignmentSampleStride);
  Serial.print(" moving_samples_per_leg="); Serial.print(500 * kAlignCycles / kAlignmentSampleStride + 1);
  Serial.print(" expected_samples="); Serial.println(2 * (500 * kAlignCycles / kAlignmentSampleStride + 1) + 3);
  Serial.println("ALIGN_TRACE_BEGIN: outputs disabled; command is electrical field displacement; leg 0/1=forward/reverse, 2/3=settled endpoints.");
  Serial.println("align_us,leg,field_displacement_rad,encoder_angle_rad,ia_adc,ib_adc,ic_adc,vbus_adc");
  for (uint16_t n = 0; n < alignmentCount; ++n) {
    const auto& row = trace[n];
    Serial.print(row.elapsedUs); Serial.print(','); Serial.print(row.loopUs); Serial.print(',');
    Serial.print(row.openFieldAngle, 6); Serial.print(','); Serial.print(row.angle, 6); Serial.print(',');
    Serial.print(row.iaAdc); Serial.print(','); Serial.print(row.ibAdc); Serial.print(',');
    Serial.print(row.icAdc); Serial.print(','); Serial.println(row.vbusAdc);
  }
  Serial.println("TRACE_END");
  reportIndexReferences();
}

bool alignSlowly() {
  const AlignmentPlan plan(currentCoverageTest);
  const uint32_t alignmentBeganUs=micros();
  alignmentFailure=nullptr;
  Serial.print("ALIGN_PROFILE cycles=");Serial.print(plan.cycles);
  Serial.print(" step_ms=4 voltage_V=.7 max_alignment_us=");Serial.println(plan.deadlineUs);
  auto waitWithStop = [alignmentBeganUs,&plan](uint32_t duration) {
    const uint32_t start = millis();
    while (millis() - start < duration) {
      if (plan.expired(micros(),alignmentBeganUs)) {alignmentFailure="coverage alignment exceeded 20 seconds";return false;}
      encoder.update();
      if (benchTest && alignmentRangeValid) {
        alignmentMinimum=fmin(alignmentMinimum,encoder.getAngle());alignmentMaximum=fmax(alignmentMaximum,encoder.getAngle());
        if (micros()-alignmentBeganUs>18000000u) {alignmentFailure="bench alignment exceeded 18 seconds";return false;}
      }
      if (!updateObservedFrame()) return false;
      if (benchTest) alignmentPeakPhase=benchCurrentGuard.peakPhase;
      if (Serial.available() && Serial.read() == 's') return false;
      delay(1);
    }
    return true;
  };
  if (benchTest) {
    encoder.update();alignmentOrigin=alignmentMinimum=alignmentMaximum=alignmentAfterPull=encoder.getAngle();
    alignmentRangeValid=true;alignmentPullComplete=false;
  }
  motor.setPhaseVoltage(kAlignVoltage, 0, _3PI_2);
  if (!waitWithStop(700)) return false;
  if (benchTest) {alignmentAfterPull=encoder.getAngle();alignmentPullComplete=true;}
  const float before = encoder.getAngle();
  alignmentCount = 0; alignmentStartUs = micros();
  recordAlignment(0, 2);
  for (int step = 0; step <= plan.steps(); ++step) {
    motor.setPhaseVoltage(kAlignVoltage, 0, _3PI_2 + _2PI * step / 500.0f);
    if (!waitWithStop(4)) return false;
    if (step % kAlignmentSampleStride == 0) recordAlignment(_2PI * step / 500.0f, 0);
  }
  if (!waitWithStop(700)) return false;
  const float middle = encoder.getAngle();
  recordAlignment(_2PI * plan.cycles, 2);
  for (int step = plan.steps(); step >= 0; --step) {
    motor.setPhaseVoltage(kAlignVoltage, 0, _3PI_2 + _2PI * step / 500.0f);
    if (!waitWithStop(4)) return false;
    if (step % kAlignmentSampleStride == 0) recordAlignment(_2PI * step / 500.0f, 1);
  }
  if (!waitWithStop(700)) return false;
  const float after = encoder.getAngle();
  recordAlignment(0, 3);
  const float forward = middle - before, reverse = middle - after;
  Serial.print("ALIGN measured radians forward/reverse: ");
  Serial.print(forward, 5); Serial.print('/'); Serial.println(reverse, 5);
  motor.pp_check_result = plan.passes(forward,reverse,kMotorPolePairs);
  if (!motor.pp_check_result) return false;
  motor.sensor_direction = forward > 0 ? Direction::CW : Direction::CCW;
  motor.zero_electric_angle = _normalizeAngle(
      static_cast<int>(motor.sensor_direction) * kMotorPolePairs * encoder.getMechanicalAngle());
  motor.setPhaseVoltage(0, 0, 0);
  return true;
}

// The library's custom callback runs after its single shaft-velocity read and
// uses its existing motion downsampling. PID gains and voltage bounds are kept.
float asymmetricVelocityControl(FOCMotor* controlled) {
  if (!running) return 0;
  if (fixedUqTest > 0) {
    controlled->shaft_velocity_sp = 0; // This diagnostic has no speed target.
    unslewedPidUq = 0; // PID is not called in this mode.
    return magnitudeSlew.update(fixedUqTest, micros());
  }
  controlled->shaft_velocity_sp = controlled->target;
  unslewedPidUq = controlled->PID_velocity(controlled->target - controlled->shaft_velocity);
  return magnitudeSlew.update(unslewedPidUq, micros(), forwardOnlyTest);
}

float probedCurrentVelocityControl(FOCMotor* controlled) {
  if (!running) return 0;
  const uint32_t elapsedUs=micros()-traceStartUs;
  controlled->shaft_velocity_sp=currentStaticProbeTest ? 0 : controlled->target;
  const float pid=currentStaticProbeTest ? controlled->target : controlled->PID_velocity(controlled->target-controlled->shaft_velocity);
  auto& probe=activeCurrentProbe();
  const float total=probe.mix(pid,elapsedUs,controlled->current_limit);
  if (feedforwardCount<16 && (!feedforwardCount || elapsedUs-lastFeedforwardUs>=(currentStaticProbeTest ? 61000u : 173000u))) {
    feedforwardTrace[feedforwardCount++]={elapsedUs,pid,probe.value,total};lastFeedforwardUs=elapsedUs;
  }
  return total;
}

float adaptiveCurrentVelocityControl(FOCMotor* controlled) {
  if (!running) return 0;
  const uint32_t now=micros(),elapsedUs=now-traceStartUs;
  controlled->shaft_velocity_sp=controlled->target;
  const float error=controlled->target-controlled->shaft_velocity;
  const float pid=controlled->PID_velocity(error);
  auto& adaptive=activeAdaptive();
  const float total=adaptive.update(static_cast<int>(controlled->sensor_direction)*encoder.getAngle(),error,
      controlled->shaft_velocity,pid,controlled->current_limit,controlled->target<0 ? -1 : 1,now);
  if (feedforwardCount<16 && (!feedforwardCount || elapsedUs-lastFeedforwardUs>=173000)) {
    feedforwardTrace[feedforwardCount++]={elapsedUs,pid,adaptive.correction,total};lastFeedforwardUs=elapsedUs;
  }
  return total;
}

float compensatedCurrentVelocityControl(FOCMotor* controlled) {
  if (!running) return 0;
  const uint32_t elapsedUs = micros() - traceStartUs;
  const uint8_t count = indexReferenceCount;
  for (uint8_t n = positionFeedforward.seenIndices; n < count; ++n)
    positionFeedforward.observeIndex(indexReferences[n].angle, elapsedUs);
  positionFeedforward.update(encoder.getAngle(), static_cast<int>(controlled->sensor_direction), elapsedUs);
  controlled->shaft_velocity_sp = controlled->target;
  const float pid = controlled->PID_velocity(controlled->target-controlled->shaft_velocity);
  const float total = positionFeedforward.mix(pid, controlled->current_limit);
  if (feedforwardCount < 16 && (!feedforwardCount || elapsedUs-lastFeedforwardUs >= 200000)) {
    feedforwardTrace[feedforwardCount++] = {elapsedUs, pid, positionFeedforward.correction, total};
    lastFeedforwardUs = elapsedUs;
  }
  return total;
}

void startTest(bool openLoop = false, bool asymmetric = false, bool forwardOnly = false, float fixedUq = 0, float pGain = 0.20f, float velocityFilter = 0.05f, bool currentCapture = false, bool phasePulse = false, CurrentTrial currentTrial = CurrentTrial::none, bool alignmentSurvey = false, bool edgeCapture = false, float rawOpenGoal = kOpenTargetVelocity, uint32_t rawOpenRampUs=2000000u, bool benchAlignment=false) {
  if (!ready || attempted || manualLocked || runEdges.busy()) {
    Serial.println("Rejected: unavailable or already attempted; reset for another test.");
    return;
  }
  attempted = true;
#if defined(BENCH_HIGH_SPEED_RPM) && BENCH_HIGH_SPEED_RPM==240
  if ((currentTrial==CurrentTrial::benchMotionPositive || currentTrial==CurrentTrial::benchMotionNegative) && kFastCurrentQLpfS==.001f && (BenchMotion::currentLimit==.45f || (BenchMotion::currentLimit==.40f && kFastVoltageLimit==.7f))) {
    Serial.println("Rejected: failed 240rpm/1ms-current-filter condition; no identical retry.");return;
  }
#endif
  benchMotionTest=currentTrial==CurrentTrial::benchMotionPositive || currentTrial==CurrentTrial::benchMotionNegative;
  benchMotion.reset(micros(),currentTrial==CurrentTrial::benchMotionNegative ? -1:1);benchMotionStats={};
  benchPositionTest=benchMotionTest || currentTrial==CurrentTrial::benchJointPositive || currentTrial==CurrentTrial::benchJointNegative;
  benchBrakeTest=currentTrial==CurrentTrial::benchCoast || currentTrial==CurrentTrial::benchBrakeActive;
  benchBrake.reset(micros(),currentTrial==CurrentTrial::benchBrakeActive);
  benchDriveTest=benchBrakeTest || benchPositionTest || currentTrial==CurrentTrial::benchPulse05 || currentTrial==CurrentTrial::benchPulse10;
  benchJoint.reset(micros(),currentTrial==CurrentTrial::benchJointNegative ? -1:1);
  benchPulseAmplitude=currentTrial==CurrentTrial::benchPulse10 ? .10f:.05f;
  benchAlignmentTest=benchAlignment;benchTest=benchDriveTest || benchAlignmentTest;benchReported=false;
  benchStartupPending=benchDriveTest;benchFirstPiElapsedUs=0;
  benchCurrentGuard.reset();alignmentRangeValid=false;alignmentPeakPhase=0;
  rawEdgeTest=edgeCapture;
  rawHighOpenTest=rawEdgeTest && rawOpenGoal==ReferenceSpeedGuard::maximumGoal;
  openVelocityGoal=rawHighOpenTest ? ReferenceSpeedGuard::maximumGoal : kOpenTargetVelocity;
  if (rawHighOpenTest && rawOpenRampUs!=800000u && rawOpenRampUs!=2000000u) {stopMotor("invalid raw open-loop ramp");return;}
  if (rawEdgeTest && rawOpenGoal!=kOpenTargetVelocity && !rawHighOpenTest) {stopMotor("invalid raw open-loop speed");return;}
  if (rawEdgeTest && (!openLoop || alignmentSurvey || currentTrial!=CurrentTrial::none || !currentCapture)) {stopMotor("invalid raw edge observation profile");return;}
  switch (currentTrial) {
    case CurrentTrial::none: fixedIqGoal = 0; break;
    case CurrentTrial::fixed015: fixedIqGoal = .15f; break;
    case CurrentTrial::benchMotionPositive: case CurrentTrial::benchMotionNegative: case CurrentTrial::benchCoast: case CurrentTrial::benchBrakeActive: case CurrentTrial::benchJointPositive: case CurrentTrial::benchJointNegative: case CurrentTrial::benchPulse05: case CurrentTrial::benchPulse10: fixedIqGoal=0; break;
    case CurrentTrial::fixed025: fixedIqGoal = .25f; break;
    case CurrentTrial::velocity: fixedIqGoal = 0; break;
    case CurrentTrial::velocityCompensated: fixedIqGoal = 0; break;
    case CurrentTrial::velocityRolling: fixedIqGoal = 0; break;
    case CurrentTrial::velocityProbe: fixedIqGoal = 0; break;
    case CurrentTrial::staticProbe: fixedIqGoal = .10f; break;
    case CurrentTrial::staticProbe10: fixedIqGoal = .10f; break;
    case CurrentTrial::velocityFastIntegral: fixedIqGoal = 0; break;
    case CurrentTrial::velocityReverse: fixedIqGoal = 0; break;
    case CurrentTrial::velocityCoverage: fixedIqGoal = 0; break;
    case CurrentTrial::velocityLongWindow: fixedIqGoal = 0; break;
    case CurrentTrial::velocityLowerFilter: fixedIqGoal = 0; break;
    case CurrentTrial::velocityDense: fixedIqGoal = 0; break;
    case CurrentTrial::velocityDenseLowerP: fixedIqGoal = 0; break;
    case CurrentTrial::velocityHigherI: fixedIqGoal = 0; break;
    case CurrentTrial::velocityHigherIReverse: fixedIqGoal = 0; break;
    case CurrentTrial::velocityStrongerI: fixedIqGoal = 0; break;
    case CurrentTrial::velocityStrongerIReverse: fixedIqGoal = 0; break;
    case CurrentTrial::velocityHigherIDense: fixedIqGoal = 0; break;
    case CurrentTrial::velocityStrongerIDense: fixedIqGoal = 0; break;
    case CurrentTrial::velocityAdaptive: fixedIqGoal = 0; break;
    case CurrentTrial::velocityAdaptiveZero: fixedIqGoal = 0; break;
    case CurrentTrial::velocityResponseProbe: fixedIqGoal = 0; break;
    case CurrentTrial::velocityResponseProbeInverse: fixedIqGoal = 0; break;
    case CurrentTrial::velocityAdaptiveFlat: fixedIqGoal = 0; break;
    case CurrentTrial::velocityHigherP: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed2: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed2LowerI: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed2LowerP: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed3LowerP: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed2LowerFilter: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed25LowerFilter: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed3LowerFilter: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed25HalfFilter: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed25Dense: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed2Dense: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed25Adaptive: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed25AdaptiveZero: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed3Adaptive: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed25SlowRamp: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60CurrentFilter: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60LowGain: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60ModerateI: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60Balanced: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60Damped: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60HalfCurrent: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60MidP: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60Edge: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60EdgeCycles: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60EdgeLowerP: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60EdgeFast: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60EdgeTracking: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60EdgeTrackingLowerP: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60EdgeTracking5: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60EdgeTracking5CurrentI: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60Response: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60ResponseInverse: fixedIqGoal = 0; break;
    case CurrentTrial::velocitySpeed60Adaptive14: fixedIqGoal = 0; break;
    default: stopMotor("invalid nominal current profile"); return;
  }
  currentIqTest = currentTrial != CurrentTrial::none;
  const bool highResponseTrial=currentTrial == CurrentTrial::velocitySpeed60Response || currentTrial == CurrentTrial::velocitySpeed60ResponseInverse;
  currentResponseProbeInverseTest=currentTrial == CurrentTrial::velocityResponseProbeInverse || currentTrial == CurrentTrial::velocitySpeed60ResponseInverse;
  currentResponseProbeTest=currentTrial == CurrentTrial::velocityResponseProbe || currentResponseProbeInverseTest || highResponseTrial;
  const bool halfHighCurrentTrial=currentTrial == CurrentTrial::velocitySpeed60HalfCurrent;
  const bool softerEdgeTrial=currentTrial == CurrentTrial::velocitySpeed60EdgeLowerP;
  const bool trackingLowerPTrial=currentTrial == CurrentTrial::velocitySpeed60EdgeTrackingLowerP;
  currentSpeed60Adaptive14Test=currentTrial == CurrentTrial::velocitySpeed60Adaptive14;
  const bool trackingCurrentITrial=currentTrial == CurrentTrial::velocitySpeed60EdgeTracking5CurrentI || highResponseTrial || currentSpeed60Adaptive14Test;
  const bool tracking5Trial=currentTrial == CurrentTrial::velocitySpeed60EdgeTracking5 || trackingCurrentITrial;
  const bool trackingTimeTrial=currentTrial == CurrentTrial::velocitySpeed60EdgeTracking || trackingLowerPTrial || tracking5Trial;
  const bool fastEdgeTrial=currentTrial == CurrentTrial::velocitySpeed60EdgeFast || trackingTimeTrial;
  const bool edgeCycleTrial=currentTrial == CurrentTrial::velocitySpeed60EdgeCycles || softerEdgeTrial || fastEdgeTrial;
  const bool edgeHighTrial=currentTrial == CurrentTrial::velocitySpeed60Edge || edgeCycleTrial;
  const bool middleHighTrial=currentTrial == CurrentTrial::velocitySpeed60MidP || edgeHighTrial;
  const bool dampedHighTrial=currentTrial == CurrentTrial::velocitySpeed60Damped || halfHighCurrentTrial || middleHighTrial;
  const bool balancedHighTrial=currentTrial == CurrentTrial::velocitySpeed60Balanced || dampedHighTrial;
  const bool moderateHighITrial=currentTrial == CurrentTrial::velocitySpeed60ModerateI || balancedHighTrial;
  const bool reducedHighTrial=currentTrial == CurrentTrial::velocitySpeed60LowGain || moderateHighITrial;
  const bool fastCurrentTrial=currentTrial == CurrentTrial::velocitySpeed60CurrentFilter || reducedHighTrial;
  currentHighSpeedTest=currentTrial == CurrentTrial::velocitySpeed60 || fastCurrentTrial;
  const bool slowRampTrial=currentTrial == CurrentTrial::velocitySpeed25SlowRamp;
  currentSpeed3AdaptiveTest=currentTrial == CurrentTrial::velocitySpeed3Adaptive;
  currentSpeed25AdaptiveTest=currentTrial == CurrentTrial::velocitySpeed25Adaptive || currentTrial == CurrentTrial::velocitySpeed25AdaptiveZero || slowRampTrial;
  currentAdaptiveZeroTest=currentTrial == CurrentTrial::velocityAdaptiveZero || currentTrial == CurrentTrial::velocitySpeed25AdaptiveZero || slowRampTrial;
  currentAdaptiveFlatTest=currentTrial == CurrentTrial::velocityAdaptiveFlat;
  currentAdaptiveTest=currentTrial == CurrentTrial::velocityAdaptive || currentAdaptiveZeroTest || currentAdaptiveFlatTest || currentSpeed25AdaptiveTest || currentSpeed3AdaptiveTest || currentSpeed60Adaptive14Test;
  const bool higherIReverseTrial=currentTrial == CurrentTrial::velocityHigherIReverse;
  const bool strongerIReverseTrial=currentTrial == CurrentTrial::velocityStrongerIReverse;
  const bool strongerITrial=currentTrial == CurrentTrial::velocityStrongerI || strongerIReverseTrial || currentTrial == CurrentTrial::velocityStrongerIDense;
  const bool higherPTrial=currentTrial == CurrentTrial::velocityHigherP;
  const bool speed3LowerFilterTrial=currentTrial == CurrentTrial::velocitySpeed3LowerFilter || currentSpeed3AdaptiveTest;
  const bool speed3Trial=currentTrial == CurrentTrial::velocitySpeed3LowerP || speed3LowerFilterTrial;
  const bool speedLowerPTrial=currentTrial == CurrentTrial::velocitySpeed2LowerP || currentTrial == CurrentTrial::velocitySpeed3LowerP;
  const bool speed2LowerITrial=currentTrial == CurrentTrial::velocitySpeed2LowerI || speedLowerPTrial;
  const bool halfFilterTrial=currentTrial == CurrentTrial::velocitySpeed25HalfFilter;
  const bool speed2DenseTrial=currentTrial == CurrentTrial::velocitySpeed2Dense;
  const bool speed25DenseTrial=currentTrial == CurrentTrial::velocitySpeed25Dense;
  const bool speed25Trial=currentTrial == CurrentTrial::velocitySpeed25LowerFilter || halfFilterTrial || speed25DenseTrial || currentSpeed25AdaptiveTest;
  const bool speed2LowerFilterTrial=currentTrial == CurrentTrial::velocitySpeed2LowerFilter || speed2DenseTrial || speed25Trial || speed3LowerFilterTrial;
  const bool speed2Trial=currentTrial == CurrentTrial::velocitySpeed2 || (speed2LowerFilterTrial && !speed25Trial && !speed3Trial) || (speed2LowerITrial && !speed3Trial);
  const bool higherITrial=currentTrial == CurrentTrial::velocityHigherI || higherIReverseTrial || strongerITrial || currentTrial == CurrentTrial::velocityHigherIDense || currentAdaptiveTest || currentResponseProbeTest || currentHighSpeedTest || higherPTrial || ((speed2Trial || speed25Trial || speed3LowerFilterTrial) && !speed2LowerITrial);
  currentCoverageTest = currentTrial == CurrentTrial::velocityCoverage;
  currentReverseTest = currentTrial == CurrentTrial::velocityReverse || currentCoverageTest || higherIReverseTrial || strongerIReverseTrial;
  currentVelocityGoal=referenceSpeedGuardActive() ? ReferenceSpeedGuard::maximumGoal : speed3Trial ? 3.0f : speed25Trial ? 2.5f : speed2Trial ? 2.0f : currentReverseTest ? -kTargetVelocity : kTargetVelocity;
  currentSpeedRampUs=rawHighOpenTest ? rawOpenRampUs : fastEdgeTrial ? 800000u : currentHighSpeedTest ? 2000000u : slowRampTrial ? 1500000u : (speed2Trial || speed25Trial || speed3Trial) ? 800000u : 0u;
  const bool lowerPTrial=currentTrial == CurrentTrial::velocityDenseLowerP;
  const bool denseTrial=currentHighSpeedTest || currentTrial == CurrentTrial::velocityDense || speed25DenseTrial || speed2DenseTrial || lowerPTrial || currentTrial == CurrentTrial::velocityHigherIDense || currentTrial == CurrentTrial::velocityStrongerIDense;
  currentFastIntegralTest = currentTrial == CurrentTrial::velocityFastIntegral || currentReverseTest || currentTrial == CurrentTrial::velocityLongWindow || currentTrial == CurrentTrial::velocityLowerFilter || denseTrial || higherITrial || speed2LowerITrial;
  currentVelocityTest = currentTrial == CurrentTrial::velocity || currentTrial == CurrentTrial::velocityCompensated || currentTrial == CurrentTrial::velocityRolling || currentTrial == CurrentTrial::velocityProbe || currentFastIntegralTest;
  encoder.useRolling = benchDriveTest || rawHighOpenTest || currentTrial == CurrentTrial::velocityRolling || currentTrial == CurrentTrial::velocityProbe || currentFastIntegralTest;
  encoder.rolling.longWindow = currentTrial == CurrentTrial::velocityLongWindow;
  encoder.rolling.shortWindow=reducedHighTrial;
  encoder.useEdge=edgeHighTrial || benchMotionTest;encoder.edgeControlActive=false;encoder.edgeDwtClock=edgeCycleTrial || rawEdgeTest || benchMotionTest;
  if (edgeCycleTrial || rawEdgeTest || benchMotionTest) {
    if (SystemCoreClock!=170000000u || !BoardCurrentObserver::gatesOff() || (DWT->CTRL&DWT_CTRL_NOCYCCNT_Msk)) {stopMotor("DWT clock unavailable while disabled");return;}
    CoreDebug->DEMCR|=CoreDebug_DEMCR_TRCENA_Msk;DWT->CTRL|=DWT_CTRL_CYCCNTENA_Msk;__DSB();__ISB();
    const uint32_t clockBefore=DWT->CYCCNT;delayMicroseconds(20);
    const uint32_t clockElapsed=DWT->CYCCNT-clockBefore;
    if (clockElapsed<1700 || clockElapsed>170000) {stopMotor("DWT clock did not advance at expected rate");return;}
    uint32_t regressions=0,maximumBackstep=0,previousCore=micros();
    const uint32_t auditStart=DWT->CYCCNT;
    for (uint32_t audit=0;audit<100000 && DWT->CYCCNT-auditStart<8500000u;++audit) {
      const uint32_t mask=__get_PRIMASK();__disable_irq();const uint32_t coreNow=micros();__set_PRIMASK(mask);
      if (coreNow-previousCore>0x7fffffffu) {++regressions;maximumBackstep=fmax(maximumBackstep,previousCore-coreNow);}
      previousCore=coreNow;
    }
    Serial.print("EDGE_CLOCK_CHECK advancing=1 gates_off=1 cycles_per_us=170 core_regressions=");Serial.print(regressions);
    Serial.print(" maximum_core_backstep_us=");Serial.println(maximumBackstep);
  }
  encoder.guardFilter = LowPassFilter(.002f); // Age through alignment, matching the first-call reset of the controller LPF.
  currentFeedforwardTest = currentTrial == CurrentTrial::velocityCompensated;
  currentStaticProbe10Test = currentTrial == CurrentTrial::staticProbe10;
  currentStaticProbeTest = currentTrial == CurrentTrial::staticProbe || currentStaticProbe10Test;
  currentProbeTest = currentTrial == CurrentTrial::velocityProbe || currentStaticProbeTest || currentResponseProbeTest;
  const bool projectTracking=currentVelocityTest || currentStaticProbeTest || benchDriveTest;
  tracePeriodUs=benchBrakeTest ? 2000 : benchPositionTest ? 10000 : benchDriveTest ? 1000 : currentStaticProbeTest ? 4000 : (denseTrial || rawHighOpenTest) ? 2000 : kTracePeriodUs;
  currentProbe.reset();staticCurrentProbe.reset();staticCurrentProbe10.reset();
  responseCurrentProbe.reset();responseCurrentProbeInverse.reset();
  positionFeedforward.reset(); feedforwardCount = 0; lastFeedforwardUs = 0;
  encoder.window.periodUs = benchDriveTest || currentVelocityTest || rawHighOpenTest ? 2000 : 10000;
  alignmentOnlyTest = alignmentSurvey;
  phasePulseTest = phasePulse;
  observeCurrents = currentCapture || currentIqTest;
  if (observeCurrents) {
    if (senseAttempted) { stopMotor("ADC already attempted; reset required"); return; }
    senseAttempted = true;
    Serial.println("CURRENT_INIT: driver disabled, calibrate observer before alignment; no current control.");
    if (!currentObserver.beginDisabled(driver)) { stopMotor("ADC observer initialization failed"); return; }
    observedFrame = currentObserver.read();
    observationGuard.reset(BoardCurrentObserver::busVoltage(observedFrame.vbus));
    Serial.print("SENSE_OFFSETS_ADC ");
    for (int n = 0; n < 3; ++n) { if (n) Serial.print(','); Serial.print(currentObserver.offset[n], 3); }
    Serial.println();
    Serial.print("CURRENT_CONFIG observer_only="); Serial.print(currentIqTest ? 0 : 1);
    Serial.print(" bus_low_V="); Serial.print(observationGuard.busLow, 4);
    Serial.print(" bus_high_V="); Serial.print(observationGuard.busHigh, 4);
    Serial.println(" deviation_delay_us=20000 max_age_us=2000 nominal_ADC_ref_V=3.3 shunt_ohm=.003 gain=-64/7");
    if (!updateObservedFrame()) { stopMotor(observationFaultReason()); return; }
  }
  openTest = openLoop;
  fixedUqTest = fixedUq;
  asymmetricTest = asymmetric || fixedUqTest > 0;
  forwardOnlyTest = asymmetric && forwardOnly;
  if (currentIqTest) {
    observerSense.linkDriver(&driver);
    if (!observerSense.init()) { stopMotor("current adapter not ready"); return; }
    motor.linkCurrentSense(&observerSense);
    motor.updateTorqueControlType(TorqueControlType::foc_current);
    motor.controller = currentVelocityTest ? MotionControlType::velocity : MotionControlType::torque;
    motor.updateCurrentLimit(benchBrakeTest ? BenchBrake::currentLimit : benchMotionTest ? BenchMotion::currentLimit : benchPositionTest ? BenchJoint::currentLimit : currentVelocityTest ? .45f : currentStaticProbeTest || benchDriveTest ? .15f : fixedIqGoal); // Nominal setpoint bound only.
    if (currentVelocityTest) {
      // Explicit current-mode gains; CONTROL records the actual trial settings.
      motor.PID_velocity.P = (softerEdgeTrial || trackingLowerPTrial) ? .075f : middleHighTrial ? .12f : dampedHighTrial ? .15f : balancedHighTrial ? .075f : reducedHighTrial ? .025f : higherPTrial ? .20f : (lowerPTrial || speedLowerPTrial) ? .10f : currentFastIntegralTest ? .15f : .20f;
      motor.PID_velocity.I = moderateHighITrial ? 1.20f : reducedHighTrial ? .30f : strongerITrial ? 9.60f : higherITrial ? 7.20f : currentFastIntegralTest ? 4.80f : 1.20f;
      motor.PID_velocity.D = 0;
      motor.PID_velocity.output_ramp = 0; // Project d/q voltage limits remain active.
      motor.LPF_velocity.Tf = reducedHighTrial ? .0005f : halfFilterTrial ? .0005f : currentFeedforwardTest ? .005f : (currentTrial == CurrentTrial::velocityLowerFilter || speed2LowerFilterTrial || currentHighSpeedTest) ? .001f : .002f; // Freeze rejected f at its measured reference profile.
    }
    motor.PID_current_q.P = motor.PID_current_d.P = .20f;
    motor.PID_current_q.I = motor.PID_current_d.I = 50.0f;
    motor.PID_current_q.D = motor.PID_current_d.D = 0;
    // Current-velocity comparison uses project slew and immediate release.
    motor.PID_current_q.output_ramp = motor.PID_current_d.output_ramp = projectTracking ? 0.0f : 3.0f;
    motor.asymmetricCurrentVoltage = projectTracking;
    motor.trackingCurrentControl = projectTracking;
    if (projectTracking) {
      motor.qPI.P = .60f; motor.qPI.I = benchDriveTest || trackingCurrentITrial ? 400.0f : currentStaticProbeTest || currentFastIntegralTest ? 200.0f : 100.0f;
      motor.qPI.voltageLimit=motor.dPI.voltageLimit=benchMotionTest ? kFastVoltageLimit:kVoltageLimit;
      motor.qSlew.voltageLimit=motor.dSlew.voltageLimit=benchMotionTest ? kFastVoltageLimit:kVoltageLimit;
      motor.qPI.trackingTimeS=benchDriveTest || tracking5Trial ? .005f : trackingTimeTrial ? .002f:0;motor.dPI.trackingTimeS=0;
      motor.qSlew.riseRateVPerS = motor.qSlew.negativeRiseRateVPerS = currentFeedforwardTest ? 30.0f : 100.0f;
    }
    if (projectTracking) {
      // The project PI uses the library's filtered dq measurement and supplies
      // actuator feedback. Leave the unused stock PI at zero in this mode.
      motor.PID_current_q.P = motor.PID_current_d.P = 0;
      motor.PID_current_q.I = motor.PID_current_d.I = 0;
    }
    motor.LPF_current_q.Tf = motor.LPF_current_d.Tf = benchDriveTest ? .001f : halfHighCurrentTrial ? .0005f : fastCurrentTrial ? .001f : .002f;
#ifdef BENCH_HIGH_SPEED_RPM
    if(benchMotionTest)motor.LPF_current_q.Tf=kFastCurrentQLpfS;
#endif
    if (benchDriveTest) motor.LPF_velocity.Tf=benchMotionTest ? .001f:.005f;
    if (currentFeedforwardTest) {
      motor.controller = MotionControlType::custom;
      motor.linkCustomMotionControl(compensatedCurrentVelocityControl);
    } else if (currentProbeTest) {
      motor.controller = MotionControlType::custom;
      motor.linkCustomMotionControl(probedCurrentVelocityControl);
    } else if (currentAdaptiveTest) {
      motor.controller = MotionControlType::custom;
      motor.linkCustomMotionControl(adaptiveCurrentVelocityControl);
    }
  }
  if (asymmetricTest) {
    motor.PID_velocity.P = pGain;
    motor.controller = MotionControlType::custom;
    motor.linkCustomMotionControl(asymmetricVelocityControl);
    motor.PID_velocity.output_ramp = 0; // MagnitudeSlew applies build-up externally.
    motor.LPF_velocity.Tf = velocityFilter;
    motor.PID_velocity.I = 0.15f;
  }
  Serial.print("CONFIG encoder_ppr=1000 counts_per_turn=4000 estimator_window_us=");
  Serial.print(encoder.window.periodUs); Serial.println(" trace_window_us=10000 raw=legacy_shadow");
  if (encoder.useEdge) {
    Serial.println(benchMotionTest ? "ESTIMATOR controller=edge_period4_phase guard=original_window2ms_LPF2ms guard_limit=BENCH_MOTION" : "ESTIMATOR controller=edge_period4_phase guard=original_window2ms_LPF2ms guard_limit_rad_s=8.5 guard_profile=reference_envelope");
    Serial.print("EDGE_ESTIMATOR_CONFIG counts_per_turn=4000 period_intervals=4 phase_gain_s_inv=");Serial.print(static_cast<int>(EdgeVelocity::phaseGain));
    Serial.print(" prediction_count_bound=1 sample_gap_limit_us=");Serial.print(EdgeVelocity::sampleGapLimitUs);
    Serial.print(" no_edge_decay=gap_to_2gap isr=integer_only");
    Serial.println(encoder.edgeDwtClock ? " clock=DWT_elapsed cycles_per_us=170" : "");
  } else if (encoder.useRolling) {
    Serial.print(rawHighOpenTest ? "ESTIMATOR observer=rolling_LS" : "ESTIMATOR controller=rolling_LS");Serial.print(encoder.rolling.horizonUs()/1000);Serial.print("ms min_sample_us=");Serial.print(encoder.rolling.minimumSampleUs());
    Serial.print(" warmup_span_us=");Serial.print(encoder.rolling.warmupUs());Serial.println(benchMotionTest ? " guard=original_window2ms_LPF2ms guard_limit=BENCH_MOTION" : referenceSpeedGuardActive() ? " guard=original_window2ms_LPF2ms guard_limit_rad_s=8.5 guard_profile=reference_envelope" : " guard=original_window2ms_LPF2ms guard_limit_rad_s=5");
  }
  if (rawEdgeTest) Serial.println("RUN_EDGE_CONFIG capacity=256 clock=DWT_elapsed origin=beginTrace storage=manual_edges raw=us,count,AB UART=after_stop");
  if (rawHighOpenTest) {Serial.print("RUN_EDGE_DRIVE speed_PID=off current_PI=off voltage_cap_V=.5 reference_ramp_us=");Serial.print(currentSpeedRampUs);Serial.println(" running_UART=off");}
  reportPwm();
  if (benchTest) {
    Serial.print("BENCH_PROFILE kind=");Serial.print(benchMotionTest ? "motion" : benchBrakeTest ? "brake" : benchPositionTest ? "position" : benchDriveTest ? "current_pulse":"alignment");
    Serial.print(" amplitude_nominal_A=");Serial.print(benchDriveTest && !benchPositionTest && !benchBrakeTest ? benchPulseAmplitude:0,3);
    if(benchMotionTest){Serial.print(BenchMotion::currentLimit==.40f ? " iq_limit_nominal_A=.40 vector_limit_V=":" iq_limit_nominal_A=.45 vector_limit_V=");Serial.print(kFastVoltageLimit==.7f ? ".7":".5");Serial.print(" pulse_duration_us=");}
    else Serial.print(benchBrakeTest ? " iq_limit_nominal_A=.22 vector_limit_V=.5 pulse_duration_us=" : benchPositionTest ? " iq_limit_nominal_A=.30 vector_limit_V=.5 pulse_duration_us=" : " iq_limit_nominal_A=.15 vector_limit_V=.5 pulse_duration_us=");
    Serial.print(benchPositionTest || benchBrakeTest ? 0:300000);
    Serial.print(" trace_period_us=");Serial.print(benchBrakeTest ? 2000 : benchPositionTest ? 10000:1000);
    Serial.println(" run_phase_limit_A=.60 align_phase_limit_A=2.2 phase_frames=3 dq_limit_A=.50 dq_delay_us=2000 align_deadline_us=18000000 motor_only=1 ratio_for_analysis=8 startup_clock=first_foc trace_clock=first_foc");
  }
  if (benchBrakeTest) {
    Serial.print("BENCH_BRAKE active=");Serial.print(benchBrake.active ? 1:0);
    Serial.println(" acceleration_iq_A=.22 acceleration_ramp_us=10000 zero_us=40000 trigger_velocity_rad_s=2 trigger_guard_rad_s=2 trigger_earliest_us=50000 acceleration_deadline_us=400000 brake_iq_A=-.20 brake_release_rad_s=.1 brake_duration_us=150000 trace_period_us=2000 position_limit_motor_rad=.418879 control_gap_us=5000 trace_layout=brake_ab_union transition_trace=forced transition_voltage=after_disable reference_update=loop_direct");
  }
  if(benchMotionTest){
    Serial.print("BENCH_MOTION direction=");Serial.print(benchMotion.direction);
    Serial.print(" rpm=");Serial.print(BenchMotion::rpm);Serial.print(" shape=");Serial.print(BenchMotion::shape);
    Serial.print(" move_us=");Serial.print(BenchMotion::moveUs);Serial.print(" duration_us=");Serial.print(BenchMotion::durationUs);
    Serial.print(" speed_limit_rad_s=");Serial.print(BenchMotion::speedLimit,6);
#ifdef BENCH_HIGH_SPEED_RPM
    Serial.print(" peak_motor_rad_s=");Serial.print(BenchMotion::peakMotor,6);
    Serial.print(" final_joint_deg=");Serial.print(BenchMotion::finalJoint/BenchMotion::degree,6);
    Serial.print(" position_limit_joint_deg=");Serial.print(BenchMotion::positionLimit/BenchMotion::degree,6);
    Serial.println(" amplitude_motor_deg=560 initial_us=100000 brake_us=250000 final_us=400000 absolute_error_limit_joint_deg=3 error_limit_joint_deg=1 error_delay_us=20000 control_period_us=250 control_gap_us=1000 position_P=30 velocity_P=.12 velocity_I=1.2 velocity_limit=peak_motor hold_enter_deg=.05 hold_exit_deg=.075 reference_update=loop_direct trajectory=quartic_accel_smooth_brake trace=moving160_80_hold10ms stats=all_FOC_samples");
#else
    Serial.println(" amplitude_motor_deg=30 initial_us=100000 hold_us=400000 final_us=500000 position_limit_joint_deg=6 error_limit_joint_deg=1 error_delay_us=100000 control_gap_us=5000 position_P=30 velocity_P=.12 velocity_I=1.2 velocity_limit=peak_motor hold_enter_deg=.05 hold_exit_deg=.075 reference_update=loop_direct trace=moving96_hold10ms stats=all_FOC_samples");
#endif
  }
  if (!benchMotionTest && benchPositionTest) {
    Serial.print("BENCH_JOINT direction=");Serial.print(benchJoint.direction);
    Serial.println(" amplitude_deg=.5 ramp_us=100000 duration_us=2700000 trace_period_us=10000 position_P=30 velocity_P=.05 velocity_I=3.0 velocity_feedforward=1 velocity_command_limit_deg_s=5 position_limit_deg=3 guard_window_us=20000 guard_limit_deg_s=15 error_limit_deg=1 error_delay_us=100000 control_gap_us=5000 nominal_iq_limit_A=.30 trace_layout=joint_ab_union integral_policy=clear_opposing_position hold_policy=velocity_damping enter_deg=.05 exit_deg=.075");
  }
  if (currentIqTest) {
    if (currentVelocityTest) {
      Serial.print("DRIVE current_velocity=1 speed_target_rad_s=");Serial.print(currentVelocityGoal,6);
      Serial.println(" nominal_iq_limit_A=.45 current_control=on legacy_raw_velocity=not_recorded");
    }
    else {
      Serial.print("DRIVE fixed_iq_nominal_A="); Serial.print(fixedIqGoal, 4);
      Serial.println(" ramp_us=300000 speed_target=none speed_PID=off current_control=on legacy_raw_velocity=not_recorded");
    }
    Serial.print("CURRENT_LOOP q_P=");
    Serial.print(projectTracking ? motor.qPI.P : motor.PID_current_q.P, 2);
    Serial.print(" q_I=");
    Serial.print(projectTracking ? motor.qPI.I : motor.PID_current_q.I, 1);
    Serial.print(" d_P=.20 d_I=50 D=0 q_voltage_build_up_V_s=");
    Serial.print(projectTracking ? motor.qSlew.riseRateVPerS : 3.0f, 1);
    Serial.print(" current_LPF_s="); Serial.print(motor.LPF_current_q.Tf, 4);
    Serial.print(" vector_voltage_limit_V=");
    if(benchMotionTest)Serial.print(kFastVoltageLimit==.7f ? ".7":".5");else Serial.print(".5");
    Serial.print(" release=");
    Serial.println(projectTracking ? "immediate reversal=via_zero; nominal current scaling" : "symmetric; nominal current scaling");
    if (projectTracking) Serial.println("CURRENT_ENGINE project_tracking_PI=1 actuator_feedback=applied_dq stock_current_PI=unused");
    if (trackingTimeTrial || benchDriveTest) {
      Serial.print("CURRENT_TRACKING q_backcalc_s=");Serial.print(motor.qPI.trackingTimeS,4);
      Serial.print(" d_backcalc_s=");Serial.println(motor.dPI.trackingTimeS,4);
    }
    if (projectTracking) {
      Serial.print("CURRENT_SLEW positive_q_V_s="); Serial.print(motor.qSlew.riseRateVPerS, 1);
      Serial.print(" negative_q_V_s="); Serial.print(motor.qSlew.negativeRiseRateVPerS, 1);
      Serial.println(" d_V_s=3 release=immediate reversal=via_zero");
    }
    Serial.print("CURRENT_TELEMETRY running_stream_CSV=off trace=RAM period_us=");Serial.print(tracePeriodUs);Serial.println(" stop_and_commands=enabled");
    if (currentFeedforwardTest)
      Serial.println("CURRENT_FF_CONFIG order=84 cos_A=-.0085 sin_A=.0253 correction_bound_A=.03 total_bound_A=.45 gate_us=800000 blend_us=200000 requires_two_matching_Index=1");
    if (currentProbeTest) {
      const auto& probe=activeCurrentProbe();
      Serial.print("CURRENT_PROBE frequency_Hz="); Serial.print(probe.frequencyHz,2);
      Serial.print(" phase_rad=");Serial.print(probe.phaseRad,6);
      Serial.print(" amplitude_nominal_A="); Serial.print(probe.amplitudeA,4);
      Serial.print(" start_us=");Serial.print(probe.gateUs);Serial.print(" blend_us=");Serial.print(probe.blendUs);
      Serial.print(" total_bound_A=");Serial.print(motor.current_limit,4);
      Serial.print(" stationary_attempt=");Serial.print(currentStaticProbeTest ? 1 : 0);Serial.println(" excitation_only=1");
    }
  }
  if (fixedUqTest > 0) {
    Serial.print("DRIVE fixed_uq_V="); Serial.print(fixedUqTest, 4);
    Serial.println(" speed_PID=off speed_target=none sensor_commutation=on");
  }
  if (asymmetricTest) {
    Serial.print("LIMITER asymmetric: magnitude build-up "); Serial.print(magnitudeSlew.riseRateVPerS, 3);
    Serial.print("V/s, immediate release, reversal via zero, bound ");
    Serial.println(forwardOnlyTest ? "0..0.5V" : "+/-0.5V");
    Serial.print("OUTPUT_POLICY forward_only="); Serial.println(forwardOnlyTest ? 1 : 0);
  }
  if (currentAdaptiveTest) {
    Serial.print("ADAPTIVE_CONFIG order=");Serial.print(activeAdaptive().order);Serial.print(" learning_rate=");Serial.print(activeAdaptive().learningRate,4);
    Serial.print(" correction_bound_nominal_A=");Serial.print(activeAdaptive().boundA,6);
    Serial.print(" response_lag_rad=");Serial.print(activeAdaptive().responseLagRad,6);
    Serial.print(" gate_us=800000 blend_us=200000 total_limit_nominal_A=");Serial.print(motor.current_limit,4);
    Serial.print(" learning_reference_rad_s=");Serial.print(activeAdaptive().referenceMagnitude,4);
    Serial.print(" learning_min_velocity_rad_s=");Serial.print(.3f*activeAdaptive().referenceMagnitude,4);
    Serial.print(" learning_max_velocity_rad_s=");Serial.print(1.7f*activeAdaptive().referenceMagnitude,4);
    Serial.print(" anchor=run_start per_run_reset=1");
    Serial.println(currentSpeed60Adaptive14Test ? " trig=phase_rotation" : "");
  }
  if (currentVelocityTest || currentStaticProbeTest) {
    Serial.print("GUARD_PEAK_CONFIG steady_start_us=");Serial.print(currentSpeedRampUs>800000 ? currentSpeedRampUs : 800000);
    Serial.println(" observation=post_move current_voltage=previous_FOC iq_next=post_move sample_age=velocity_call UART=after_stop");
  }
  if (referenceSpeedGuardActive()) {
    Serial.println("SPEED_GUARD_CONFIG mode=reference_envelope deviation_rad_s=2 hard_abs_rad_s=8.5 max_target_rad_s=6.283185 source=original_window2ms_LPF2ms signed_motor_velocity=1");
    Serial.print("VELOCITY_STATS_CONFIG period_us=2000 start_us=");Serial.print(currentSpeedRampUs);Serial.println(" source=ABI_interval frame=motor_signed samples=post_ramp_only UART=after_stop");
  }
  Serial.print("CONTROL P="); Serial.print(motor.PID_velocity.P, 4);
  Serial.print(" I="); Serial.print(motor.PID_velocity.I, 4);
  Serial.print(" D="); Serial.print(motor.PID_velocity.D, 4);
  Serial.print(" output_ramp_V_s="); Serial.print(motor.PID_velocity.output_ramp, 4);
  Serial.print(" velocity_LPF_s="); Serial.println(motor.LPF_velocity.Tf, 4);
  if (currentSpeedRampUs) {
    Serial.print("REFERENCE_RAMP duration_us=");Serial.print(currentSpeedRampUs);
    Serial.print(" target_rad_s=");Serial.print(currentVelocityGoal,6);
    Serial.println(" trace_target=final_goal origin=trace_start");
  }
  Serial.print("TRACE_CONFIG period_us=");Serial.print(tracePeriodUs);
  Serial.println(" capacity=320 loop_us_saturation=65535 window_age_us_saturation=65535 window_span_us_nominal=10000");
  if (denseTrial || rawHighOpenTest) Serial.println("TRACE_SCOPE retained_tail_only=1 nominal_span_us=640000 whole_run_guard_stats=1 velocity_window_us=10000");
  if (phasePulseTest) {
    Serial.println("DRIVE phase_pulse=1 amplitude_V=.10 rise_V_s=3 pulse_us=150000 rest_us=100000 count=6 total_us=1500000 speed_PID=off speed_target=none Uq_column=unused");
    if (!motor.init()) { stopMotor("motor init failed"); return; }
    encoder.update();
    startAngle = encoder.getAngle();
    runStart = millis();
    beginTrace();
    running = true;
    Serial.println("RUN PHASE: U+/U-/V+/V-/W+/W- static vectors, max .10V, 1.5 seconds; velocity and ADC/VBUS guards retained.");
    return;
  }
  if (openTest) {
    motor.controller = MotionControlType::velocity_openloop;
    motor.velocity_limit = openVelocityGoal;
    motor.motion_downsample = 0;
    if (!motor.init()) { stopMotor("motor init failed"); return; }
    Serial.println("ALIGN OPEN: establish starting field before speed ramp.");
    if (!alignSlowly()) { stopMotor("open-loop starting alignment failed"); return; }
    motor.updateVoltageLimit(kOpenVoltageLimit);
    // Continue from the exact electrical field used at the end of alignment.
    motor.shaft_angle = _3PI_2 / kMotorPolePairs;
    encoder.update();
    startAngle = encoder.getAngle();
    runStart = millis();
    beginTrace();
    if (rawEdgeTest && !runEdges.active) {stopMotor("raw edge storage unavailable");return;}
    running = true;
    if (rawEdgeTest) {
      Serial.print("RUN_EDGE_ACTIVE window_us=");Serial.print(encoder.window.periodUs);
      Serial.print(" guard_LPF_s=");Serial.print(rawHighOpenTest ? encoder.guardFilter.Tf : observedVelocity.Tf,4);
      Serial.print(rawHighOpenTest ? " guard_limit_rad_s=8.5 voltage_limit_V=" : " guard_limit_rad_s=5 voltage_limit_V=");Serial.print(motor.voltage_limit,3);
      Serial.print(" target_rad_s=");Serial.print(motor.velocity_limit,rawHighOpenTest ? 6:3);
      Serial.println(motor.controller==MotionControlType::velocity_openloop ? " mode=open_loop" : " mode=unexpected");
    }
    Serial.print("RUN OPEN: ramp speed to "); Serial.print(openVelocityGoal, rawHighOpenTest ? 6:3);
    Serial.print(" rad/s at "); Serial.print(kOpenVoltageLimit, 3);
    Serial.println(" V; stop after 3 seconds.");
    return;
  }
  Serial.print("ALIGNING: slow 0.7 V, ");Serial.print(currentCoverageTest ? 4 : kAlignCycles);
  Serial.println(" electrical turns each way, with settling.");
  if (!motor.init()) { stopMotor("motor init failed"); return; }
  if (!alignSlowly()) {
    stopMotor(observeCurrents && (observationGuard.fault != ObservationGuard::none || (benchTest && benchCurrentGuard.fault!=BenchCurrentGuard::none)) ? observationFaultReason() : alignmentFailure ? alignmentFailure : "slow alignment aborted or pole-pair check failed");
    return;
  }
  if (alignmentOnlyTest) {
    stopMotor("alignment survey complete");
    dumpAlignment();
    return;
  }
  if (!motor.initFOC()) { stopMotor("FOC alignment failed"); return; }
  if (!motor.pp_check_result) { stopMotor("pole-pair check failed"); return; }
  motor.updateVoltageLimit(benchMotionTest ? kFastVoltageLimit:kVoltageLimit);
  if (currentIqTest) {
    motor.current_sp = motor.target = 0;
    motor.PID_current_q.reset(); motor.PID_current_d.reset();
    // Clear filter state after alignment while preserving the selected trial.
    motor.LPF_current_q = LowPassFilter(motor.LPF_current_q.Tf);
    motor.LPF_current_d = LowPassFilter(motor.LPF_current_d.Tf);
    motor.vectorBoundEnabled = true;
    motor.qSlew.reset(micros()); motor.dSlew.reset(micros());
    motor.qPI.reset(micros()); motor.dPI.reset(micros());
    Serial.print("CURRENT_ACTIVE q_LPF_s="); Serial.print(motor.LPF_current_q.Tf, 4);
    Serial.print(" d_LPF_s="); Serial.print(motor.LPF_current_d.Tf, 4);
    Serial.print(" velocity_LPF_s="); Serial.print(motor.LPF_velocity.Tf, 4);
    Serial.print(" q_P=");Serial.print(motor.trackingCurrentControl ? motor.qPI.P : motor.PID_current_q.P,4);
    Serial.print(" q_I=");Serial.print(motor.trackingCurrentControl ? motor.qPI.I : motor.PID_current_q.I,4);
    Serial.print(" velocity_P=");Serial.print(motor.PID_velocity.P,4);
    Serial.print(" velocity_I=");Serial.println(motor.PID_velocity.I,4);
    if (trackingTimeTrial || benchDriveTest) {
      Serial.print("CURRENT_TRACKING_ACTIVE q_backcalc_s=");Serial.print(motor.qPI.trackingTimeS,4);
      Serial.print(" d_backcalc_s=");Serial.println(motor.dPI.trackingTimeS,4);
    }
#ifdef BENCH_HIGH_SPEED_RPM
    if(benchMotionTest){
      Serial.print("FAST_VOLTAGE_ACTIVE vector_limit_V=");Serial.print(motor.voltage_limit,4);
      Serial.print(" q_integrator_limit_V=");Serial.print(motor.qPI.voltageLimit,4);
      Serial.print(" d_integrator_limit_V=");Serial.print(motor.dPI.voltageLimit,4);
      Serial.print(" q_slew_limit_V=");Serial.print(motor.qSlew.voltageLimit,4);
      Serial.print(" d_slew_limit_V=");Serial.println(motor.dSlew.voltageLimit,4);
      Serial.print("FAST_CURRENT_ACTIVE iq_limit_nominal_A=");Serial.println(motor.current_limit,4);
    }
#endif
  }
  if (benchDriveTest) benchCurrentGuard.reset();
  // initFOC's cached angle can age while UART metadata is emitted. Refresh
  // before the reference and velocity-window reset, without reading velocity.
  encoder.update();
  startAngle = encoder.getAngle();
  runStart = millis();
  beginTrace();
  running = true;
  if (currentStaticProbeTest) Serial.println("RUN CURRENT: 1-second stationary attempt, nominal Iq .10A plus .02A probe, setpoint cap .15A; .03rad displacement stop; all existing guards retained.");
  else if (currentVelocityTest) {
    Serial.print("RUN CURRENT VELOCITY: target ");Serial.print(currentVelocityGoal,6);
    Serial.println(currentHighSpeedTest ? "rad/s, nominal Iq limit +/-.45A, vector cap .5V; reference envelope/stall/3s guards." : "rad/s, nominal Iq limit +/-.45A, vector cap .5V; existing speed/stall/3s guards.");
  }
  else if (benchBrakeTest) Serial.println("RUN BENCH BRAKE: bounded acceleration, then coast or negative current; motor-only.");
  else if(benchMotionTest){
#ifdef BENCH_HIGH_SPEED_RPM
    Serial.println("RUN BENCH MOTION: bounded 560deg motor acceleration plus separate smooth brake; motor-only.");
#else
    Serial.println("RUN BENCH MOTION: bounded 30deg motor trajectory; motor-only.");
#endif
  }
  else if (benchPositionTest) Serial.println("RUN BENCH JOINT: virtual motor/8 position; 2.7s; motor-only.");
  else if (benchDriveTest) Serial.println("RUN BENCH CURRENT: balanced signed pulses; nominal Iq cap .15A; vector .5V; run 300ms.");
  else if (currentIqTest) Serial.println("RUN CURRENT: 300ms ramp to nominal Iq target; vector cap .5V; existing speed/stall/3s guards.");
  else if (fixedUqTest > 0) Serial.println("RUN FIXED: ramp to fixed Uq at 3V/s; no speed target; same 5rad/s and stall guards; max 3 seconds.");
  else Serial.println("RUN: target 1 rad/s for 3 seconds, voltage limited to 0.5 V.");
}

void setup() {
  const uint32_t gates[] = {PA8, PC13, PA9, PA12, PA10, PB15};
  for (uint32_t pin : gates) {
    digitalWrite(pin, LOW);
    pinMode(pin, OUTPUT);
  }
  Serial.begin(115200);
  SimpleFOCDebug::enable(&Serial);
  encoder.pullup = Pullup::USE_EXTERN;
  encoder.init();
  abiQuality.reset(abiState());
  encoder.enableInterrupts(onA, onB);
  pinMode(PB8, INPUT);
  attachInterrupt(digitalPinToInterrupt(PB8), onIndex, RISING);
  driver.voltage_power_supply = kBusVoltage;
  driver.voltage_limit = kBusVoltage;
  driver.pwm_frequency = kPwmFrequency;
  driver.dead_zone = kPwmDeadZone;
  ready = driver.init();
  if (ready) {
    driver.disable();
    BoardCurrentObserver::configureGatePullDowns();
  }
  motor.linkDriver(&driver);
  motor.linkSensor(&encoder);
  motor.controller = MotionControlType::velocity;
  motor.torque_controller = TorqueControlType::voltage;
  motor.voltage_limit = kAlignVoltage;
  motor.voltage_sensor_align = kAlignVoltage;
  motor.velocity_limit = 2.0f;
  motor.PID_velocity.P = 0.20f;
  motor.PID_velocity.I = 0.15f;
  motor.PID_velocity.D = 0;
  motor.PID_velocity.output_ramp = kVelocityOutputRamp;
  motor.LPF_velocity.Tf = 0.05f;
  motor.motion_downsample = 4;
  Serial.println(ready ? "READY: gates OFF. t=closed-loop, a=P.20, b=P.10, d=P.10 Tf.02, p=forward-only, o=open-loop, u=fixed .20V, v=fixed .25V, s=stop; one test per boot."
                       : "ERROR: PWM driver init failed; no test possible.");
  Serial.println("Current feedback is disabled at boot; r/n/m enable nominal current control. Supply current limit must remain enabled.");
  Serial.print("DIAG v"); Serial.print(kDiagVersion);
  Serial.println(": m=current velocity, g=rolling speed, q/Q=forward/reverse candidate, w=velocity current probe, z/y=1s static 20/10Hz probes, f=Index correction, r/n=nominal .15/.25A Iq; e=alignment survey; l=observed open-loop; k=phase pulses; j=observed b; i=ADC-only.");
  Serial.println("C=reverse candidate with 4-cycle alignment/20s alignment deadline; H=forward candidate with 8ms rolling speed; run ceiling remains 3s.");
  Serial.println("L=forward candidate with velocity LPF 1ms, rolling speed 4ms; speed guard retains window2ms/LPF2ms.");
  Serial.println("D=forward candidate with 2ms RAM trace, last ~.64s only; all drive settings and guards unchanged.");
  Serial.println("E=D with velocity P reduced from .15 to .10, I remains 4.80; bounds and guards unchanged.");
  Serial.println("I=forward candidate with velocity I 7.20 instead of 4.80, P .15; full 3s RAM trace and unchanged bounds/guards.");
  Serial.println("R=I with target -1rad/s; q/Q remain forward/reverse I4.80 references.");
  Serial.println("B=I with velocity I 9.60 instead of 7.20; same speed, bounds and guards.");
  Serial.println("S=B with target -1rad/s; M/N=forward I7.20/I9.60 with 2ms RAM tails; same bounds/guards.");
  Serial.println("A/Z=I7.20 with bounded per-run adaptive order84 correction / zero-learning comparison; .03A correction and existing total/voltage/velocity limits.");
  Serial.println("T/U=I7.20 with 17.5Hz/.02A known probe at phase 0/pi; adaptive correction off, existing bounds/guards.");
  Serial.println("V=I with velocity P .20 instead of .15; I7.20, target 1rad/s, existing bounds/guards.");
  Serial.println("W=I at 2rad/s with 800ms reference ramp; trace target column is final goal; existing bounds/guards.");
  Serial.println("J=W with velocity I4.80 instead of 7.20; same reference, P .15, bounds and guards.");
  Serial.println("K=J with velocity P .10; X is not cleared and is rejected. Original 5rad/s/3s/current/voltage/ADC guards remain.");
  Serial.println("Y=W with velocity LPF 1ms instead of 2ms; rolling4ms and independent window2ms/LPF2ms guard unchanged.");
  Serial.println("3=60rpm lower velocity gains P.025/I.30, LS2ms/velocityLPF.5ms/currentLPF1ms; G/1 disabled after envelope faults. Same 2s ramp, +/-2 envelope, absolute8.5 ceiling; legacy profiles retain fixed5.");
  Serial.println("0=8 at 2.5rad/s with reference ramp1.5s instead of .8s; zero learning, same bounds/guards.");
  Serial.println("9 disabled after near-limit speed3 peaks; P/X remain disabled; independent guard remains 5rad/s.");
  Serial.println("7/8=O with bounded adaptive order84 / zero-learning comparison, lag45deg and learning reference2.5; .03A correction and existing bounds/guards.");
  Serial.println("5=O at 2.5rad/s, 6=Y at 2rad/s; 2ms RAM tails, last ~.65s only; same 3s drive and all guards.");
  Serial.println("O=Y at 2.5rad/s; 2=O with velocity LPF .5ms; same 800ms ramp and original bounds/guards. P disabled after overspeed.");
  Serial.println("F=A with the adaptive response-lag hypothesis 0rad instead of .785398rad; same correction and total bounds.");
  reportPwm();
  Serial.println("ms,running,A_edges,B_edges,index,angle_rad,velocity_rad_s,Uq_V");
}

void loop() {
  while (Serial.available()) {
    const char command = Serial.read();
    if (command == 's') { stopMotor("serial stop"); endManual(); senseIdle = false; }
    else if (command == 'h') startManual();
    else if (command == 'x') endManual();
    else if (command == 'c') reportPwm();
    else if (command == 'i') startSenseIdle();
    else if (command == 'j') startTest(false, true, false, 0, 0.10f, 0.05f, true);
    else if (command == 'k') startTest(false, false, false, 0, 0.20f, 0.05f, true, true);
    else if (command == 'r') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::fixed015);
    else if (command == 'n') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::fixed025);
    else if (command == 'm') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocity);
    else if (command == 'f') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityCompensated);
    else if (command == 'g') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityRolling);
    else if (command == 'w') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityProbe);
    else if (command == 'z') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::staticProbe);
    else if (command == 'y') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::staticProbe10);
    else if (command == 'q') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityFastIntegral);
    else if (command == 'Q') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityReverse);
    else if (command == 'C') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityCoverage);
    else if (command == 'H') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityLongWindow);
    else if (command == 'L') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityLowerFilter);
    else if (command == 'D') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityDense);
    else if (command == 'E') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityDenseLowerP);
    else if (command == 'I') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityHigherI);
    else if (command == 'R') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityHigherIReverse);
    else if (command == 'B') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityStrongerI);
    else if (command == 'S') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityStrongerIReverse);
    else if (command == 'M') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityHigherIDense);
    else if (command == 'N') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityStrongerIDense);
    else if (command == 'A') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityAdaptive);
    else if (command == 'Z') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityAdaptiveZero);
    else if (command == 'T') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityResponseProbe);
    else if (command == 'U') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityResponseProbeInverse);
    else if (command == 'F') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityAdaptiveFlat);
    else if (command == 'V') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocityHigherP);
    else if (command == 'W') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocitySpeed2);
    else if (command == 'J') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocitySpeed2LowerI);
    else if (command == 'K') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocitySpeed2LowerP);
    else if (command == 'X') { stopMotor("unapproved X profile"); Serial.println("Rejected: X has not been cleared by bench evidence; output disabled."); }
    else if (command == 'Y') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocitySpeed2LowerFilter);
    else if (command == 'O') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocitySpeed25LowerFilter);
    else if (command == 'P') { stopMotor("faulted P profile disabled"); Serial.println("Rejected: P exceeded the independent speed guard; output disabled."); }
    else if (command == 'G') { stopMotor("faulted G profile disabled"); Serial.println("Rejected: G exceeded its reference envelope; output disabled."); }
    else if (command == '1') { stopMotor("faulted currentLPF1 profile disabled"); Serial.println("Rejected: 1 exceeded its reference envelope; output disabled."); }
    else if (command == '3') { stopMotor("faulted lowgain profile disabled"); Serial.println("Rejected: 3 exceeded its reference envelope; output disabled."); }
    else if (command == '4') { stopMotor("faulted moderateI profile disabled"); Serial.println("Rejected: 4 exceeded its reference envelope; output disabled."); }
    else if (command == '=') { stopMotor("faulted balanced profile disabled"); Serial.println("Rejected: = exceeded its reference envelope; output disabled."); }
    else if (command == '>') { stopMotor("faulted damped profile disabled"); Serial.println("Rejected: > exceeded its reference envelope; output disabled."); }
    else if (command == '<') { stopMotor("faulted half-current-filter profile disabled"); Serial.println("Rejected: < exceeded its reference envelope; output disabled."); }
    else if (command == '~') { stopMotor("faulted middle-P profile disabled"); Serial.println("Rejected: ~ exceeded its reference envelope; output disabled."); }
    else if (command == '[') { stopMotor("faulted edge-micros profile disabled"); Serial.println("Rejected: [ produced a nonfinite estimate; output disabled."); }
    else if (command == ']') { stopMotor("faulted edge-DWT profile disabled"); Serial.println("Rejected: ] exceeded its reference envelope; output disabled."); }
    else if (command == '{') { stopMotor("faulted edge-lowerP profile disabled"); Serial.println("Rejected: { exceeded its reference envelope; output disabled."); }
    else if (command == '}') startTest(true, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::none, false, true);
    else if (command == '!') { stopMotor("faulted slow-open profile disabled"); Serial.println("Rejected: ! exceeded its reference envelope; output disabled."); }
    else if (command == '+') { stopMotor("faulted fast-open profile disabled"); Serial.println("Rejected: + exceeded its reference envelope; output disabled."); }
    else if (command == '_') { stopMotor("faulted fast-edge profile disabled"); Serial.println("Rejected: _ exceeded its reference envelope; output disabled."); }
    else if (command == '@') { stopMotor("faulted tracking profile disabled"); Serial.println("Rejected: @ exceeded its reference envelope; output disabled."); }
    else if (command == '%') { stopMotor("faulted tracking-lowerP profile disabled"); Serial.println("Rejected: % exceeded its reference envelope; output disabled."); }
    else if (command == ':') { stopMotor("faulted tracking-5ms profile disabled"); Serial.println("Rejected: : exceeded its reference envelope; output disabled."); }
    else if (command == ';') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocitySpeed60EdgeTracking5CurrentI);
    else if (command == '(') { stopMotor("faulted high-response probe disabled"); Serial.println("Rejected: ( exceeded its reference envelope; output disabled."); }
    else if (command == ')') { stopMotor("unpaired high-response inverse disabled"); Serial.println("Rejected: forward trial did not complete; inverse probe not tested."); }
    else if (command == '?') { stopMotor("marginal adaptive14 profile disabled"); Serial.println("Rejected: ? approached the reference guard without reducing whole-run ripple."); }
    else if (command == '^') {stopMotor("faulted adaptive14 rotation profile disabled");Serial.println("Rejected: ^ stopped before its correction gate; output disabled.");}
    else if (command == '$') {stopMotor("faulted bench startup profile disabled");Serial.println("Rejected: initial PI interval included UART time; output disabled.");}
    else if(command == '"')startTest(false,false,false,0,.20f,.05f,true,false,CurrentTrial::benchMotionPositive);
    else if(command == '|')startTest(false,false,false,0,.20f,.05f,true,false,CurrentTrial::benchMotionNegative);
    else if (command == '#') startTest(false,false,false,0,.20f,.05f,true,false,CurrentTrial::benchCoast);
    else if (command == '-') startTest(false,false,false,0,.20f,.05f,true,false,CurrentTrial::benchBrakeActive);
    else if (command == ',') startTest(false,false,false,0,.20f,.05f,true,false,CurrentTrial::benchJointPositive);
    else if (command == '.') startTest(false,false,false,0,.20f,.05f,true,false,CurrentTrial::benchJointNegative);
    else if (command == '/') startTest(false,false,false,0,.20f,.05f,true,false,CurrentTrial::benchPulse05);
    else if (command == '&') startTest(false,false,false,0,.20f,.05f,true,false,CurrentTrial::benchPulse10);
    else if (command == '*') startTest(false,false,false,0,.20f,.05f,true,false,CurrentTrial::none,true,false,kOpenTargetVelocity,2000000u,true);
    else if (command == '0') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocitySpeed25SlowRamp);
    else if (command == '9') { stopMotor("marginal speed3 profile disabled"); Serial.println("Rejected: 9 approached the independent speed guard; output disabled."); }
    else if (command == '7') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocitySpeed25Adaptive);
    else if (command == '8') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocitySpeed25AdaptiveZero);
    else if (command == '6') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocitySpeed2Dense);
    else if (command == '5') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocitySpeed25Dense);
    else if (command == '2') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::velocitySpeed25HalfFilter);
    else if (command == 'e') startTest(false, false, false, 0, 0.20f, 0.05f, true, false, CurrentTrial::none, true);
    else if (command == 'l') startTest(true, false, false, 0, 0.20f, 0.05f, true);
    else if (command == 't') startTest();
    else if (command == 'a') startTest(false, true);
    else if (command == 'b') startTest(false, true, false, 0, 0.10f);
    else if (command == 'd') startTest(false, true, false, 0, 0.10f, 0.02f);
    else if (command == 'p') startTest(false, true, true);
    else if (command == 'o') startTest(true);
    else if (command == 'u') startTest(false, false, false, 0.20f);
    else if (command == 'v') startTest(false, false, false, 0.25f);
  }
  encoder.update();
  if (openTest || phasePulseTest || !running) measuredVelocity = observedVelocity(encoder.getVelocity());
  if (manual.active) { reportManual(); return; }
  if (running) {
    if (!updateObservedFrame()) {
      stopMotor(observationFaultReason());
      if (tracePending) dumpTrace();
      return;
    }
    const uint32_t loopNow = micros();
    loopUs = loopNow - lastLoopUs;
    lastLoopUs = loopNow;
    const uint32_t windowUs = loopNow - windowStartUs;
    if (windowUs >= 10000) {
      const float angle = encoder.getAngle();
      windowVelocity = (angle - windowAngle) * 1e6f / windowUs;
      windowAngle = angle;
      windowStartUs = loopNow;
    }
    const uint32_t elapsed = millis() - runStart;
    if (phasePulseTest) {
      commandedVelocity = 0;
      const auto voltage = PhasePulseProfile::at(micros() - traceStartUs);
      const float center = kBusVoltage / 2;
      driver.setPwm(center + voltage.a, center + voltage.b, center + voltage.c);
    } else if (openTest) {
      commandedVelocity = rawHighOpenTest ? velocityReference(openVelocityGoal,micros()-traceStartUs,currentSpeedRampUs) : kOpenTargetVelocity * _constrain(elapsed / 800.0f, 0.0f, 1.0f);
      motor.move(commandedVelocity);
      motor.loopFOC();
    } else if (currentIqTest) {
      commandedVelocity = currentVelocityTest ? velocityReference(currentVelocityGoal,micros()-traceStartUs,currentSpeedRampUs) : 0;
      const float appliedTarget = motor.current_sp;
      const unsigned brakePhaseBefore=benchBrake.phase;
      const bool firstBench=benchDriveTest && benchStartupPending;
      if (firstBench) {
        encoder.update();startAngle=encoder.getAngle();runStart=millis();beginTrace();
        if (benchMotionTest) benchMotion.reset(micros(),benchMotion.direction);
        else if (benchPositionTest) benchJoint.reset(micros(),benchJoint.direction);
        if (benchBrakeTest) benchBrake.reset(micros(),benchBrake.active);
        const uint32_t firstNow=micros();
        motor.qPI.reset(firstNow);motor.dPI.reset(firstNow);
        motor.qSlew.reset(firstNow);motor.dSlew.reset(firstNow);
        benchStartupPending=false;
      }
      motor.loopFOC();
      if (benchBrakeTest && benchBrake.coast()) {
        const auto amps=observerSense.getFOCCurrents(motor.electricalAngle());
        motor.current.q=motor.LPF_current_q(amps.q);motor.current.d=motor.LPF_current_d(amps.d);
        motor.voltage.q=motor.voltage.d=motor.current_sp=0;
      }
      if (firstBench) benchFirstPiElapsedUs=motor.qPI.elapsedUs();
      currentControlTrace = {motor.current.q, motor.current.d, motor.voltage.d, appliedTarget};
      if(benchBrakeTest)benchBrake.observeCurrent(micros()-traceStartUs,appliedTarget,currentControlTrace.iq);
      motor.move(benchBrakeTest ? benchBrake.update(micros(),micros()-traceStartUs,static_cast<int>(motor.sensor_direction)*(encoder.getAngle()-startAngle),motor.shaft_velocity,encoder.guardVelocity*static_cast<int>(motor.sensor_direction)) : benchMotionTest ? benchMotion.update(micros(),micros()-traceStartUs,static_cast<int>(motor.sensor_direction)*(encoder.getAngle()-startAngle)/8,motor.shaft_velocity/8,encoder.guardVelocity*static_cast<int>(motor.sensor_direction)) : benchPositionTest ? benchJoint.update(micros(),micros()-traceStartUs,static_cast<int>(motor.sensor_direction)*(encoder.getAngle()-startAngle)/8,motor.shaft_velocity/8) : benchDriveTest ? BenchCurrentPulse::target(micros()-traceStartUs,benchPulseAmplitude) : currentVelocityTest ? commandedVelocity : nominalIqRamp(fixedIqGoal, micros() - traceStartUs));
      if(benchBrakeTest)motor.current_sp=benchBrake.currentTarget;
      if(benchMotionTest)motor.current_sp=benchMotion.currentTarget;
      if (benchBrakeTest && benchBrake.coast()) {
        if(motor.enabled)motor.disable();
        motor.current_sp=motor.voltage.q=motor.voltage.d=0;
        currentControlTrace.ud=0;currentControlTrace.target=0;
      }
      measuredVelocity = motor.shaft_velocity;
      if (firstBench || (benchBrakeTest && brakePhaseBefore<2 && benchBrake.phase==2)) recordTrace(true,motor.voltage.q);
    } else {
      commandedVelocity = fixedUqTest > 0 ? 0.0f : kTargetVelocity;
      motor.loopFOC();
      motor.move(commandedVelocity);
      measuredVelocity = motor.shaft_velocity;
    }
    if(benchMotionTest){
      const uint32_t t=micros()-traceStartUs;float ref,feed;unsigned phase;
      BenchMotion::reference(t,benchMotion.direction,ref,feed,phase);
      benchMotionStats.observe(phase,ref-static_cast<int>(motor.sensor_direction)*(encoder.getAngle()-startAngle)/8,
          motor.shaft_velocity,currentControlTrace.target-currentControlTrace.iq,currentControlTrace.target,
          motor.voltage.q,motor.voltage.d,BoardCurrentObserver::busVoltage(observedFrame.vbus),motor.lastVectorLimited,motor.lastSlewLimited,BenchMotion::currentLimit);
      tracePeriodUs=BenchMotion::tracePeriod(t);
    }
    recordTrace(false, motor.voltage.q);
    const float monitoredVelocity = encoder.useRolling ? encoder.guardVelocity : openTest || phasePulseTest ? measuredVelocity : motor.shaft_velocity;
    lastGuardVelocity = monitoredVelocity;
    const uint32_t peakNow=micros(),peakElapsed=peakNow-traceStartUs;
    if ((currentVelocityTest || currentStaticProbeTest) && encoder.velocitySampleValid && guardPeaks.wants(monitoredVelocity,peakElapsed)) {
      guardPeaks.observe({peakElapsed,peakNow-encoder.velocitySampleUs,peakNow-observedFrame.us,
          monitoredVelocity,motor.shaft_velocity,commandedVelocity,currentControlTrace.target,motor.current_sp,
          currentControlTrace.iq,motor.voltage.q,motor.voltage.d,currentAdaptiveTest ? activeAdaptive().correction : 0});
    }
    if (referenceSpeedGuardActive()) intervalVelocityStats.update(peakNow,static_cast<int>(motor.sensor_direction)*encoder.getAngle());
    const bool invalidVelocity=!isfinite(monitoredVelocity) || !isfinite(measuredVelocity);
    bool speedGuardExceeded=fabs(monitoredVelocity)>(benchMotionTest ? BenchMotion::speedLimit:5.0f);
    if (referenceSpeedGuardActive()) {
      const auto envelope=ReferenceSpeedGuard::evaluate(monitoredVelocity*static_cast<int>(motor.sensor_direction),commandedVelocity,currentVelocityGoal);
      speedGuardExceeded=!envelope.valid || envelope.outside;
    }
    if (isfinite(monitoredVelocity)) runGuardAbsPeak = fmax(runGuardAbsPeak, fabs(monitoredVelocity));
    const bool stalled = !benchPositionTest && !phasePulseTest && motionWatchdog.stalled(encoder.getAngle(), micros());
    if (benchBrakeTest && benchBrake.invalid) stopMotor(benchBrake.reason());
    else if (benchBrakeTest && benchBrake.complete) stopMotor(benchBrake.active ? "bench active brake complete":"bench coast complete");
    else if(benchMotionTest && (benchMotion.invalid || benchMotionStats.invalid))stopMotor(benchMotion.invalid ? benchMotion.reason():"nonfinite motion statistics");
    else if (!benchMotionTest && benchPositionTest && benchJoint.invalid) stopMotor(benchJoint.reason());
    else if (currentAdaptiveTest && activeAdaptive().invalid) stopMotor("invalid adaptive correction or unexpected adaptive control gap");
    else if (currentProbeTest && activeCurrentProbe().invalid) stopMotor("invalid current probe");
    else if (currentFeedforwardTest && positionFeedforward.invalid) stopMotor("invalid position correction or inconsistent Index");
    else if (currentIqTest && motor.vectorBound.invalid) stopMotor("non-finite current voltage vector");
    else if (asymmetricTest && magnitudeSlew.invalid) stopMotor("non-finite PID output");
    else if (encoder.useEdge && !isfinite(measuredVelocity)) stopMotor("invalid edge velocity estimate or control sample gap");
    else if (invalidVelocity || speedGuardExceeded)
      stopMotor(referenceSpeedGuardActive() ? "reference speed envelope exceeded" : "unexpected velocity");
    else if (referenceSpeedGuardActive() && intervalVelocityStats.invalid) stopMotor("invalid high-rate velocity statistics");
    else if (stalled) stopMotor("shaft movement stalled");
    else if (currentStaticProbeTest && fabs(encoder.getAngle()-startAngle)>.03f) stopMotor("movement during stationary current probe");
    else if (currentStaticProbeTest && micros()-traceStartUs>=1000000) stopMotor("1-second current probe complete");
    else if (phasePulseTest && micros() - traceStartUs >= PhasePulseProfile::durationUs)
      stopMotor("1.5-second phase-pulse complete");
    else if(benchMotionTest && micros()-traceStartUs>=BenchMotion::durationUs)stopMotor("bench motion sequence complete");
    else if (!benchMotionTest && benchPositionTest && micros()-traceStartUs>=BenchJoint::durationUs) stopMotor("bench joint sequence complete");
    else if (benchDriveTest && !benchPositionTest && !benchBrakeTest && micros()-traceStartUs>=BenchCurrentPulse::durationUs) stopMotor("bench pulse sequence complete");
    else if (elapsed >= kRunMs) stopMotor("3-second test complete");
    else if (!benchPositionTest && !phasePulseTest && elapsed >= 1200 && fabs(encoder.getAngle() - startAngle) < 0.03f)
      stopMotor("no shaft movement");
  } else encoder.update();
  if (tracePending) dumpTrace();
  reportSenseIdle();
  if (running && (currentIqTest || rawHighOpenTest)) return; // Stop polling and RAM trace remain active; avoid UART stalls in current control.
  static uint32_t lastReport = 0;
  const uint32_t now = millis();
  if (now - lastReport < 200) return;
  lastReport = now;
  noInterrupts();
  const uint32_t a = edgesA, b = edgesB, i = indexPulses;
  interrupts();
  Serial.print(now); Serial.print(','); Serial.print(running); Serial.print(',');
  Serial.print(a); Serial.print(','); Serial.print(b); Serial.print(',');
  Serial.print(i); Serial.print(','); Serial.print(encoder.getAngle(), 5); Serial.print(',');
  Serial.print(measuredVelocity, 5); Serial.print(',');
  Serial.println(running ? motor.voltage.q : 0.0f, 4);
}
