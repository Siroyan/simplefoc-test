"""Offline archival and complete matrix audit. No device access."""
import hashlib,json,re,subprocess,sys,tempfile,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[1];folder=root/'docs/experiment-logs'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def portable(s):return Path(s.replace('\\','/'))
with tempfile.TemporaryDirectory(prefix='motion-final-',dir=root/'.pio') as work:
    work=Path(work);products=[]
    archive=work/'2026-11-20-motion-condition-archives.zip';manifest={}
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for version in range(162,169):
            condition=folder/f'2026-11-20-motion-v{version}-condition.json';data=json.loads(condition.read_text());base=root/portable(data['snapshot_directory'])
            for name,digest in data['sha256'].items():
                source=base/Path(name).name;assert sha(source)==digest
                entry=(portable(data['snapshot_directory']).relative_to('.pio')/source.name).as_posix()
                z.write(source,entry);manifest[entry]=digest
    products.append(archive)
    archive_manifest=work/'2026-11-20-motion-condition-archives.json'
    archive_manifest.write_text(json.dumps({'archive_sha256':sha(archive),'files_sha256':manifest},indent=2));products.append(archive_manifest)
    artifacts=work/'2026-11-20-motion-stage-artifacts.zip'
    sources=[root/'.pio'/f'{kind}-v{version}.log' for version in range(162,169) for kind in ('build','upload')]
    sources+=sorted((root/'.pio').glob('reset-*2026-11-20*.log'))+[Path(__file__).resolve()]
    with zipfile.ZipFile(artifacts,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sources:z.write(p,p.relative_to(root).as_posix())
    products.append(artifacts)
    summary=work/'2026-11-20-motion-resumed-summary.json';csv=summary.with_suffix('.csv')
    subprocess.run([sys.executable,str(root/'tools/summarize_motion.py'),'--output',str(summary),'--csv',str(csv)],check=True)
    products += [summary,csv];records=json.loads(summary.read_text())['records'];matrix=[]
    current=[r for r in records if r['kind']=='motion' and 161<=r['firmware_version']<=168]
    for shape in (0,1):
        for rpm in (10,20,40,60):
            rows=[r for r in current if r['motion']['rpm']==rpm and r['motion']['shape']==shape];assert rows
            def start(r):return re.search(r'^HOST start=(\S+)',(root/portable(r['log'])).read_text(),re.M)[1]
            rows.sort(key=start);faults=[r for r in rows if r['stop']!='STOP: bench motion sequence complete'];cancelled=6-len(rows)
            if cancelled:assert cancelled>0 and len(faults)==1 and faults[0] is rows[-1]
            else:assert len(rows)==6 and all(sum(r['motion']['direction']==d for r in rows)==3 for d in (-1,1))
            for r in rows:
                p=r['profile'];m=r['motion'];a=r['active_config']
                assert (p['iq_limit_nominal_A'],p['dq_limit_A'],p['run_phase_limit_A'],p['vector_limit_V'])==(.45,.50,.60,.5)
                assert (m['position_P'],m['velocity_P'],m['velocity_I'])==(30,.12,1.2)
                assert (a['velocity_LPF_s'],a['q_LPF_s'],a['q_P'],a['q_I'])==(.001,.001,.6,400)
                assert r['final_stop_acknowledged']
            moving=[m for r in rows for m in r['moving'] if m['FOC_samples']]
            matrix.append({'rpm':rpm,'shape':shape,'versions':sorted(set(r['firmware_version'] for r in rows)),
                'normal_trials':len(rows)-len(faults),'protective_stops':len(faults),'cancelled_trials':cancelled,'performance_pass_trials':sum(r['pass'] for r in rows),
                'max_moving_error_joint_deg':max(m['max_error_joint_deg'] for m in moving),'max_moving_iq_rms_nominal_A':max(m['rms_iq_error_nominal_A'] for m in moving),
                'max_phase_nominal_A':max(r['guard']['peak_phase_nominal_A'] for r in rows),'max_vector_V':max(m['max_vector_V'] for m in moving),
                'vector_limit_events':sum(round(m['FOC_samples']*m['vector_limited_fraction']) for m in moving),
                'vbus_min_V':min(m['vbus_min_V'] for m in moving),'vbus_max_V':max(m['vbus_max_V'] for m in moving),
                'logs':[r['log'] for r in rows],'fault_logs':[r['log'] for r in faults]})
    assert len(current)==sum(m['normal_trials']+m['protective_stops'] for m in matrix)
    matrix_file=work/'2026-11-20-motion-range045-matrix.json'
    matrix_file.write_text(json.dumps({'scope':'Same control/current range, both trajectories. Partial fault intervals retained; cancelled trials never counted as completed. No loaded or independent absolute-angle qualification.','groups':matrix},indent=2));products.append(matrix_file)
    hosts=json.loads((folder/'2026-11-20-motion-runtime-hosts.json').read_text());host_zip=folder/'2026-11-20-motion-runtime-hosts.zip';assert sha(host_zip)==hosts['archive_sha256']
    with zipfile.ZipFile(host_zip) as z:
        for fingerprint,files in hosts['hosts'].items():
            data={name:z.read(fingerprint+'/'+name) for name in files}
            assert all(hashlib.sha256(data[name]).hexdigest()==digest for name,digest in files.items())
            assert hashlib.sha256(b''.join(data[k] for k in sorted(data))).hexdigest()==fingerprint
    today=[r for r in records if portable(r['log']).name.startswith('2026-11-20-')]
    for r in today:
        text=(root/portable(r['log'])).read_text();fingerprint=re.search(r'^HOST python_source_fingerprint=(\w+)',text,re.M)[1]
        assert fingerprint in hosts['hosts'] and sha(root/portable(r['log']))==r['sha256']
    idle=folder/'2026-11-20-motion-final-v168-idle-01.log';off=idle.read_text()
    assert 'FIRMWARE diag_version=168' in off and 'gate_inputs_low=1' in off and 'HOST verified: STOP acknowledged, drive locked until reset, five output-OFF rows' in off
    condition=json.loads((folder/'2026-11-20-motion-v168-condition.json').read_text())
    for name,digest in condition['sha256'].items():
        if name.startswith(('src/','include/','.pio/observer-build/')):assert sha(root/name)==digest
    audit=work/'2026-11-20-motion-final-audit.json'
    audit.write_text(json.dumps({'offline_only':True,'today_records':len(today),'all_today_final_acknowledged':all(r['final_stop_acknowledged'] for r in today),
        'normal_matrix_trials':sum(m['normal_trials'] for m in matrix),'matrix_protective_stops':sum(m['protective_stops'] for m in matrix),'cancelled_matrix_trials':sum(m['cancelled_trials'] for m in matrix),
        'matrix_performance_pass_trials':sum(m['performance_pass_trials'] for m in matrix),'complete_firmware_snapshots_verified':list(range(162,169)),
        'runtime_source_fingerprints_verified':list(hosts['hosts']),'live_source_and_elf_match_v168':True,'final_idle_sha256':sha(idle),
        'artifact_sha256':{p.name:sha(p) for p in products},'today_raw_log_sha256':{r['log']:r['sha256'] for r in today}},indent=2));products.append(audit)
    assert all(not (folder/p.name).exists() for p in products)
    for p in products:
        with (folder/p.name).open('xb') as f:f.write(p.read_bytes())
    print(json.dumps({'published':len(products),'matrix':[{k:m[k] for k in ('rpm','shape','normal_trials','protective_stops','cancelled_trials','max_moving_error_joint_deg')} for m in matrix]}))
