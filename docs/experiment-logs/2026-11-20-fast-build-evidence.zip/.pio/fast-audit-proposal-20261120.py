"""Preserve both real trials and reviewable unflashed voltage candidate."""
import difflib,hashlib,json,re,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[1];folder=root/'docs/experiment-logs'
def sha(data):return hashlib.sha256(data).hexdigest()
records=[]
for version,rpm in ((169,120),(170,240)):
    stem=f'2026-11-20-fast-{rpm}-positive-v{version}-01';log=folder/(stem+'.log');result=json.loads((folder/(stem+'.json')).read_text())
    condition=json.loads((folder/f'2026-11-20-fast-v{version}-condition.json').read_text());archive=folder/f'2026-11-20-fast-v{version}-condition.zip'
    assert sha(archive.read_bytes())==condition['archive_sha256']
    with zipfile.ZipFile(archive) as z:
        for name,digest in condition['source_sha256'].items():assert sha(z.read(name))==digest
        host={name:z.read(name) for name in z.namelist() if name.startswith('tools/') and name.endswith('.py')}
        fingerprint=sha(b''.join(host[name] for name in sorted(host)))
    text=log.read_text();assert re.search(r'^HOST python_source_fingerprint=(\w+)',text,re.M)[1]==fingerprint==condition['host_source_fingerprint']
    assert 'HOST final_stop_acknowledged=True' in text
    idle=folder/f'2026-11-20-fast-v{version}-idle-01.log';off=idle.read_text()
    assert 'gate_inputs_low=1' in off and f'FIRMWARE diag_version={version}' in off and 'HOST verified: STOP acknowledged, drive locked until reset, five output-OFF rows' in off
    records.append({'log':log.name,'log_sha256':sha(log.read_bytes()),'result':result,'condition_archive_sha256':sha(archive.read_bytes()),'runtime_host_fingerprint':fingerprint,'idle_log':idle.name,'idle_sha256':sha(idle.read_bytes())})
baseline=json.loads((folder/'2026-11-20-fast-v170-condition.json').read_text())
for suffix in ('firmware.elf','firmware.bin'):
    name=f'.pio/observer-build/disco_b_g431b_esc1/{suffix}';assert sha((root/name).read_bytes())==baseline['source_sha256'][name]
proposal=json.loads((folder/'2026-11-20-fast-v171-proposal.json').read_text());assert proposal['state']=='built_not_flashed'
assert sha((folder/'2026-11-20-fast-v171-proposal.zip').read_bytes())==proposal['archive_sha256']
changes=[]
with zipfile.ZipFile(folder/'2026-11-20-fast-v170-condition.zip') as z:
    names=['src/main.cpp','include/TrackingCurrentPI.h','include/MagnitudeSlew.h','tools/bench_metadata.py','tools/capture_motion.py','tools/fast_motion_profile.py','tools/analyze_bench.py','tools/analyze_fast_motion.py','tools/save_fast_condition.py','test/tracking_voltage_limit.cpp','test/fast_voltage_proposal.py']
    for name in names:
        before=z.read(name).decode('utf-8').splitlines(keepends=True) if name in z.namelist() else []
        after=(root/name).read_text(encoding='utf-8').splitlines(keepends=True)
        changes.extend(difflib.unified_diff(before,after,fromfile='v170/'+name,tofile='v171/'+name))
patch=folder/'2026-11-20-fast-voltage07-v171.patch'
with patch.open('x',encoding='utf-8',newline='') as f:f.write(''.join(changes))
evidence=folder/'2026-11-20-fast-build-evidence.zip'
sources=[root/'.pio'/f'{kind}-v{version}.log' for version in (169,170) for kind in ('build','upload')]
sources += [root/'.pio/build-fast-proposal171.log',Path(__file__).resolve(),root/'.pio/fast-native-check.cmd',root/'.pio/fast-voltage-native-check.cmd']
with zipfile.ZipFile(evidence,'x',zipfile.ZIP_DEFLATED) as z:
    for p in sources:z.write(p,p.relative_to(root).as_posix())
data={'scope':'Two actual fast-motion trials plus unflashed .7V voltage-only operating-parameter proposal; no inference of 3733rpm success.',
      'records':records,'physical_version':170,'physical_OFF_locked':True,'physical_elf_bin_preserved':True,
      'candidate_version':171,'candidate_not_flashed':True,'candidate_voltage_V':.7,'candidate_current_limits_unchanged':True,
      'proposal_archive_sha256':proposal['archive_sha256'],'proposal_patch_sha256':sha(patch.read_bytes()),'build_evidence_sha256':sha(evidence.read_bytes()),
      'latest_checks':['fast-native-v169.txt: all seven trajectory variants and legacy waveform regression',
        'fast-voltage07-native-v171-02.txt: default .5V legacy PI/slew model regressions and explicit .7V full-pipeline tests',
        'fast-voltage07-protocol-v171-02.txt: declared/applied vector, integrator AND slew voltage checks; failed .5V profile refused before serial',
        'fast_motion_analysis.py: synthetic .5/.7V complete/partial data and corruption refusal'],
      'earlier_failed_native_check':'fast-voltage07-native-v171.txt found the remaining fixed .5V slew amplitude ceiling; corrected and rechecked in -02; no candidate was flashed'}
with (folder/'2026-11-20-fast-v169-v170-audit.json').open('x',encoding='utf-8') as f:json.dump(data,f,indent=2)
print('PASS: both captures and runtime fingerprints/firmware archives verified; v170 ELF/bin preserved; v171 proposal patch/build archived, unflashed')
