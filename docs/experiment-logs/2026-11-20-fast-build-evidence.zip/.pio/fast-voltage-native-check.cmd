@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
for %%t in (magnitude_slew tracking_current_pi current_tracking_time tracking_voltage_limit) do (
 cl /nologo /EHsc /std:c++17 /W4 /Iinclude test\%%t.cpp /Fo.pio\ /Fe.pio\fast-voltage-%%t.exe >>.pio\fast-voltage-native-build.log 2>&1
 if errorlevel 1 exit /b 1
 .pio\fast-voltage-%%t.exe
 if errorlevel 1 exit /b 1
)
