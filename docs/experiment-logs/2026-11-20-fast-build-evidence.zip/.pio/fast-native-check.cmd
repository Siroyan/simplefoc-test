@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
for %%r in (120 240 360 600 1200 2400 3733) do (
 cl /nologo /EHsc /std:c++17 /W4 /Iinclude /DBENCH_HIGH_SPEED_RPM=%%r test\bench_high_speed_motion.cpp /Fo.pio\ /Fe.pio\fast-native.exe >>.pio\fast-native-build.log 2>&1
 if errorlevel 1 exit /b 1
 .pio\fast-native.exe
 if errorlevel 1 exit /b 1
)
cl /nologo /EHsc /std:c++17 /W4 /Iinclude /DBENCH_MOTION_RPM=60 /DBENCH_MOTION_SHAPE=1 test\bench_motion.cpp /Fo.pio\ /Fe.pio\fast-legacy-native.exe >>.pio\fast-native-build.log 2>&1
if errorlevel 1 exit /b 1
.pio\fast-legacy-native.exe
exit /b %errorlevel%
